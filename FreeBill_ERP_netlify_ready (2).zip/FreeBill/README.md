# FreeBill ERP — Phase 1 (Frontend) + Phase 2 (Auth Backend)

A modern, glassmorphism-styled ERP/invoicing frontend built with HTML5, CSS3,
vanilla JavaScript, Bootstrap 5, Chart.js, DataTables, jsPDF and SheetJS.

**New:** `backend/` now contains a real Node.js backend for accounts and
login — every user gets a **real, randomly generated OTP emailed to them**
(currently sent from `swaroop29@icloud.com`) for registration, login, and
password reset. See **`backend/README.md`** for setup (takes ~5 minutes).
Everything else described below (customers, invoices, products, etc.) is
still Phase 1 frontend-only using `localStorage`.

## Features included

- Login / Register with **real OTP emails** (via EmailJS — see "Email OTP setup" below), permanent per-browser account storage
- Dashboard with stat cards, sales & stock charts, recent activity — **all cards, table rows, and lists are clickable** and jump to the relevant report/record
- Customers, Suppliers, Products management (full CRUD)
- Quotations (create + convert to invoice)
- Sales Invoices (line items, tax calc, **PDF export**)
- Purchase Orders, Delivery Orders
- Inventory view with stock adjustment + low-stock badges
- Reports (Sales, Product, Customer, Supplier, GST, P&L, Outstanding, Inventory)
  with chart + **Excel export**
- Settings (company profile, tax/currency, backup & restore as JSON, reset demo data)
- Profile page
- Dark mode toggle, mobile-responsive sidebar, glass-card UI, click-to-enlarge logo

## Login / Registration (now backend-powered)

Registration, login (2FA), and "Forgot Password" send **real OTP emails**
via the new Node backend in `backend/` — see `backend/README.md` for the
5-minute setup (mainly: generate an iCloud app-specific password and drop
it in `backend/.env`). The backend must be running (`node backend/server.js`)
for these pages to work; `js/api-config.js` points the frontend at it.

## Saved accounts / "lifetime" login

Usernames and passwords are stored in the browser's `localStorage`, which
**is permanent** — it survives closing the tab, restarting the device, etc.
— as long as the page is opened over `http://`/`https://` (not by
double-clicking the file). If accounts ever seem to "not save", it's almost
always one of these:

- The app was opened as a local file (`file://...`) instead of via the
  mini web server below — the app now shows a red banner warning about this.
- The browser is in private/incognito mode with storage blocked — the app
  now warns about this too.
- Site data / browser storage was manually cleared.

Because this is per-browser storage (no shared database yet), an account
created in Chrome won't show up in Firefox or on a different device — that
requires the Phase 2 backend (PHP + MySQL) mentioned below.


## How to preview

Because the pages load Bootstrap/Chart.js/DataTables from a CDN and use
`fetch`-like relative links between pages, **don't just double-click
`login.html`** — some browsers block localStorage/relative navigation on the
`file://` protocol. Instead run a tiny local web server from inside the
`FreeBill` folder:

**Option A — Python (already installed on most systems):**
```
cd FreeBill
python3 -m http.server 8000
```
Then open **http://localhost:8000** in your browser.

**Option B — VS Code:**
Install the "Live Server" extension, right-click `login.html` → "Open with Live Server".

**Option C — Node.js:**
```
cd FreeBill
npx serve .
```

### Demo login
```
Email:    admin@freebill.test
Password: admin123
```
Or just click **Create one** to register your own account — everything is
stored locally in your browser (no server/database yet, per the Phase 1 plan).

> Note: since data lives in `localStorage`, it's per-browser. Use **Settings →
> Backup & Restore** to export/import your data as JSON, e.g. to move it to
> another browser or before clearing site data.

## Folder structure

See the original plan — this matches it:
```
FreeBill/
├── index.html, login.html, register.html, dashboard.html
├── css/        → style.css, dashboard.css, responsive.css, login.css, forms.css
├── js/         → utils.js, layout.js, login.js, dashboard.js, invoice.js, ...
├── pages/      → customers, suppliers, products, quotation, invoice, purchase,
│                 delivery, inventory, reports, settings, profile
├── assets/     → logo
├── uploads/    → reserved for Phase 3 (logos/signatures/QR)
├── database/   → reserved for Phase 2 (database.sql)
├── api/        → reserved for Phase 2 (PHP endpoints)
```

## What's next (per the plan)

- **Phase 2:** PHP + MySQL backend, real authentication, multi-user, admin panel
- **Phase 3:** GST/QR invoicing, barcode scanning, WhatsApp/Email invoice sending,
  automated low-stock alerts, full backup & restore against a real database
