/* =========================================================
   FreeBill ERP backend — server.js
   Plain Node.js HTTP server (no Express/npm install required).
   Run with:  node server.js   (from inside the backend/ folder)
   ========================================================= */
const http = require('http');
const { loadEnv } = require('./lib/env');
loadEnv();

const db = require('./lib/db');
const { hashPassword } = require('./lib/crypto');
db.ensureSeed(hashPassword);

const { createRouter } = require('./lib/router');
const authRoutes = require('./routes/auth');

const router = createRouter();
authRoutes.register(router);

router.get('/api/health', async (req, res, json) => json(200, { ok: true, time: new Date().toISOString() }));

const PORT = Number(process.env.PORT || 5000);
const server = http.createServer((req, res) => router.handle(req, res));
server.listen(PORT, () => {
  console.log(`FreeBill ERP backend listening on http://localhost:${PORT}`);
});
