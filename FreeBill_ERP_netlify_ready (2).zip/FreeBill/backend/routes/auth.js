/* =========================================================
   FreeBill ERP backend — routes/auth.js
   Plain email + password auth. No OTP / email verification step —
   register and login both return a session token immediately.
   ========================================================= */
const db = require('../lib/db');
const { hashPassword, verifyPassword, signJwt, verifyJwt } = require('../lib/crypto');

function publicUser(u) {
  return {
    id: u.id,
    name: u.name,
    company: u.company,
    email: u.email,
    username: u.username,
    role: u.role,
    status: u.status,
    verified: u.verified,
    trialStartedAt: u.trialStartedAt,
    expiryDate: u.expiryDate,
    planName: u.planName
  };
}

function requireFields(body, fields) {
  for (const f of fields) {
    if (!body[f] || String(body[f]).trim() === '') return f;
  }
  return null;
}

function register(router) {
  // Create the account and log the user straight in (no OTP).
  router.post('/api/auth/register', async (req, res, json) => {
    const missing = requireFields(req.body, ['name', 'email', 'password']);
    if (missing) return json(400, { error: `Missing field: ${missing}` });

    const email = String(req.body.email).trim().toLowerCase();
    const { name, company, password } = req.body;
    if (password.length < 6) return json(400, { error: 'Password must be at least 6 characters' });

    const data = db.load();
    if (data.users.some((u) => u.email.toLowerCase() === email)) {
      return json(409, { error: 'An account with this email already exists' });
    }

    const now = new Date();
    const expiry = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    let newUser;
    await db.mutate((d) => {
      newUser = {
        id: d.nextUserId++,
        name,
        company: company || '',
        email,
        username: email,
        passwordHash: hashPassword(password),
        role: 'user',
        status: 'active',
        verified: true,
        trialStartedAt: now.toISOString().slice(0, 10),
        expiryDate: expiry.toISOString().slice(0, 10),
        planName: '1 Week Free Trial',
        createdAt: now.toISOString()
      };
      d.users.push(newUser);
    });

    const token = signJwt({ sub: newUser.id, email: newUser.email, role: newUser.role });
    json(201, { message: 'Account created', token, user: publicUser(newUser) });
  });

  // Login: check password, return a session token immediately (no OTP).
  router.post('/api/auth/login', async (req, res, json) => {
    const missing = requireFields(req.body, ['email', 'password']);
    if (missing) return json(400, { error: `Missing field: ${missing}` });
    const email = String(req.body.email).trim().toLowerCase();

    const data = db.load();
    const user = data.users.find(
      (u) => u.email.toLowerCase() === email || u.username.toLowerCase() === email
    );
    if (!user || !verifyPassword(req.body.password, user.passwordHash)) {
      return json(401, { error: 'Invalid email/username or password' });
    }
    if (user.role !== 'admin' && user.status === 'hold') {
      return json(403, { error: 'Your account is on hold by the administrator.' });
    }

    const token = signJwt({ sub: user.id, email: user.email, role: user.role });
    json(200, { message: 'Login successful', token, user: publicUser(user) });
  });

  // Forgot password: set a new password directly by email (no OTP).
  router.post('/api/auth/reset-password', async (req, res, json) => {
    const missing = requireFields(req.body, ['email', 'newPassword']);
    if (missing) return json(400, { error: `Missing field: ${missing}` });
    const email = String(req.body.email).trim().toLowerCase();
    if (req.body.newPassword.length < 6) return json(400, { error: 'Password must be at least 6 characters' });

    let found = false;
    await db.mutate((d) => {
      const user = d.users.find((u) => u.email.toLowerCase() === email);
      if (user) {
        user.passwordHash = hashPassword(req.body.newPassword);
        found = true;
      }
    });
    if (!found) return json(404, { error: 'Account not found' });
    json(200, { message: 'Password reset. Please log in with your new password.' });
  });

  // Fetch the logged-in user from a Bearer token (used to restore sessions).
  router.get('/api/auth/me', async (req, res, json) => {
    const auth = req.headers.authorization || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    const payload = token && verifyJwt(token);
    if (!payload) return json(401, { error: 'Invalid or expired session' });
    const data = db.load();
    const user = data.users.find((u) => u.id === payload.sub);
    if (!user) return json(404, { error: 'Account not found' });
    json(200, { user: publicUser(user) });
  });
}

module.exports = { register };
