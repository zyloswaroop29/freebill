# FreeBill ERP — Backend (Phase 2, part 1: Auth + Real OTP Email)

A small Node.js backend that gives FreeBill ERP **real user accounts and
real emailed OTPs** (registration, login 2FA, forgot-password) — replacing
the old browser-only localStorage + EmailJS demo from Phase 1.

**Zero npm installs required.** Everything is built with Node's built-in
modules only (`http`, `net`, `tls`, `crypto`, `fs`) — no Express, no
nodemailer, no database driver. That means `npm install` isn't needed at
all; you can deploy this to almost any host that runs Node 18+.

## What it does

- Every new signup gets a **real OTP emailed** to verify their address.
- Every login is **2‑factor**: password, then a fresh OTP emailed to the
  user, entered to complete sign-in.
- Forgot-password also emails an OTP before allowing a reset.
- All OTPs are 6 digits, expire in 5 minutes, and are rate-limited to 5
  attempts.
- Passwords are hashed with `scrypt` (never stored in plain text).
- Sessions are signed JSON Web Tokens (HS256), stored in the browser's
  `localStorage` under the key `fb_token`.
- User data is stored in `backend/data/db.json` for now (see "Moving to a
  real database" below for the upgrade path).

## 1. Configure the email sender (iCloud)

All OTP emails are currently sent from **swaroop29@icloud.com**, per your
instructions. iCloud requires an **app-specific password** — your normal
Apple ID password will be rejected by their SMTP server for third-party
apps like this one.

1. Go to <https://appleid.apple.com> → sign in.
2. **Sign-In and Security** → **App-Specific Passwords** → **Generate**.
3. Copy the generated password (looks like `abcd-efgh-ijkl-mnop`).
4. In the `backend/` folder, copy `.env.example` to `.env`:
   ```
   cd backend
   cp .env.example .env
   ```
5. Open `.env` and fill in:
   ```
   EMAIL_USER=swaroop29@icloud.com
   EMAIL_PASS=abcd-efgh-ijkl-mnop      <- the app-specific password
   JWT_SECRET=some-long-random-string  <- change this too
   ```

**When you're ready to switch the sender email later:** just edit
`EMAIL_HOST`, `EMAIL_USER`, and `EMAIL_PASS` in `.env` — no code changes
needed. The same settings pattern works for Gmail, Outlook/Office365,
Zoho, or any other STARTTLS SMTP provider (just change `EMAIL_HOST`/
`EMAIL_PORT` accordingly).

## 2. Run the backend

```
cd backend
node server.js
```

You should see:
```
FreeBill ERP backend listening on http://localhost:5000
```

Leave this running in its own terminal.

## 3. Run the frontend (as before)

In a second terminal, from the `FreeBill/` folder:
```
python3 -m http.server 8000
```
Open <http://localhost:8000>. Registration, login, and forgot-password on
`login.html`/`register.html` now call the backend automatically (see
`js/api-config.js` — it points at `http://localhost:5000/api` when running
on localhost).

## 4. Try it

- **Register** a new account → check the inbox of the email you used for
  a 6-digit OTP → enter it → account is created and you're logged in.
- **Log out**, then **log in** with that account's password → a *second*
  OTP is emailed → enter it to finish signing in.
- **Forgot password** → enter your email → OTP is emailed → enter it plus
  a new password.
- The original demo admin still works: `admin@freebill.test` / `admin123`
  (also goes through the OTP step now, since you asked for *all* users to
  get one).

If SMTP isn't configured yet, the API still works — the JSON responses
include a `devOtp` field in non-production mode so you can keep testing
before the email side is wired up. Remove/ignore that field once real
email delivery is confirmed (it's automatically omitted when
`NODE_ENV=production`).

## ⚠️ Netlify will NOT run this backend by itself

Netlify (and most static-site hosts like Vercel/GitHub Pages/Cloudflare
Pages) only serve **static files**. `backend/server.js` is a normal,
persistent Node process — Netlify has no way to run that on its own.

If you deployed the `FreeBill/` folder to Netlify and pointed
`js/api-config.js` at `/api` on that same Netlify domain, every request
was actually hitting Netlify's fallback page (still `200 OK`, but HTML,
not JSON) — which is why the app *said* "OTP sent" but nothing ever
arrived. (That false-positive has been fixed — it now throws a clear
error instead of pretending to succeed.)

**Fix: host the backend somewhere that runs real Node, separately from
the Netlify frontend.** The frontend on Netlify is fine to keep as-is —
it just needs to point at the right backend URL.

### Easiest option: Render.com (free tier, no code changes)

1. Push this project (or at least the `backend/` folder) to a GitHub repo.
2. Go to <https://render.com> → **New** → **Web Service** → connect the repo.
3. Settings:
   - **Root Directory:** `backend`
   - **Build Command:** *(leave empty — no npm install needed)*
   - **Start Command:** `node server.js`
4. Under **Environment**, add the same variables from `.env.example`:
   `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USER`, `EMAIL_PASS`, `JWT_SECRET`, `NODE_ENV=production`.
5. Deploy. Render gives you a URL like `https://freebill-backend.onrender.com`.
6. Open `js/api-config.js` and set:
   ```js
   const FB_API_BASE = 'https://freebill-backend.onrender.com/api';
   ```
7. Re-deploy the frontend to Netlify with that change.

(Railway and Fly.io work the same way if you prefer those instead —
same idea: root directory `backend`, start command `node server.js`.)

### If you specifically want everything on Netlify

That means rewriting `backend/server.js`'s routes as **Netlify
Functions** (each route becomes its own serverless function file). It's
doable but is a real rework, not a config change — say the word and I'll
do that conversion instead.

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create account, email OTP |
| POST | `/api/auth/verify-register` | Verify OTP, activate account, start 7-day trial, return session token |
| POST | `/api/auth/login` | Check password, email a login OTP |
| POST | `/api/auth/verify-login` | Verify login OTP, return session token |
| POST | `/api/auth/forgot-password` | Email a reset OTP |
| POST | `/api/auth/reset-password` | Verify OTP + set new password |
| POST | `/api/auth/resend-otp` | Resend an OTP (`{email, purpose}`, purpose = register/login/reset) |
| GET | `/api/auth/me` | Restore session from `Authorization: Bearer <token>` |
| GET | `/api/health` | Health check |

## What's NOT wired up yet (known scope)

To keep this change focused, only **authentication** was moved to the
backend. The rest of the app (customers, invoices, products, the admin
panel's user list, etc.) still reads/writes `localStorage`, same as
Phase 1. That means:

- Accounts you register now live in `backend/data/db.json` (real,
  shared, cross-device) — but the **Admin panel's user management page**
  still shows/edits the old localStorage copy, so it won't see new
  signups yet.
- Moving those other pages onto the backend (multi-user shared data,
  admin panel, subscriptions, etc.) is a good next step once you're happy
  with the auth/OTP piece — happy to take that on next.

## Moving to a real database later

`backend/lib/db.js` is a small JSON-file store, intentionally isolated
behind a few functions (`load`, `mutate`, `ensureSeed`) so it can be
swapped for MySQL/Postgres/etc. later without touching the route files in
`backend/routes/`. Given the project's original Phase 2 plan mentioned
MySQL, that's a natural next step for scaling past a handful of
concurrent users.

## Deploying for real (so Play Store / production users can reach it)

- Put the backend on any Node host (Render, Railway, a small VPS, etc.),
  set the same `.env` variables there.
- Point `js/api-config.js`'s production branch (`/api`) at your real
  domain, or reverse-proxy `/api` on the same domain as the frontend so
  browsers don't need CORS at all.
- Set `CORS_ORIGIN` in `.env` to your real frontend domain instead of `*`
  once you're live.
- A packaged mobile app (Play Store) would need the static frontend
  wrapped (e.g. with Capacitor) or rebuilt natively — that's a separate
  step from this backend and we can plan it once the web app is fully on
  the backend.
