/* =========================================================
   FreeBill ERP — customer.js
   ========================================================= */

let customerTable;

function loadCustomers(){
  const data = FB.get(FB.KEYS.customers, []);
  const tbody = document.querySelector('#customerTable tbody');
  tbody.innerHTML = '';
  data.forEach(c => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${c.name}</td>
        <td>${c.company||'-'}</td>
        <td>${c.gst||'-'}</td>
        <td>${c.email||'-'}</td>
        <td>${c.phone||'-'}</td>
        <td>${FB.money(c.balance||0)}</td>
        <td class="row-actions">
          <button class="icon-btn" onclick="editCustomer('${c.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deleteCustomer('${c.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  if(customerTable) customerTable.destroy();
  customerTable = $('#customerTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search customers...'} });
}

function openCustomerModal(){
  document.getElementById('customerForm').reset();
  document.getElementById('custId').value = '';
  document.getElementById('customerModalTitle').textContent = 'Add Customer';
}

function editCustomer(id){
  const data = FB.get(FB.KEYS.customers, []);
  const c = data.find(x => x.id === id);
  if(!c) return;
  document.getElementById('customerModalTitle').textContent = 'Edit Customer';
  document.getElementById('custId').value = c.id;
  document.getElementById('custName').value = c.name;
  document.getElementById('custCompany').value = c.company||'';
  document.getElementById('custGst').value = c.gst||'';
  document.getElementById('custEmail').value = c.email||'';
  document.getElementById('custPhone').value = c.phone||'';
  document.getElementById('custAddress').value = c.address||'';
  new bootstrap.Modal(document.getElementById('customerModal')).show();
}

function deleteCustomer(id){
  if(!confirm('Delete this customer?')) return;
  let data = FB.get(FB.KEYS.customers, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.customers, data);
  loadCustomers();
  FB.toast('Customer deleted', 'info');
}

document.getElementById('customerForm').addEventListener('submit', function(e){
  e.preventDefault();
  const id = document.getElementById('custId').value;
  const data = FB.get(FB.KEYS.customers, []);
  const payload = {
    name: document.getElementById('custName').value.trim(),
    company: document.getElementById('custCompany').value.trim(),
    gst: document.getElementById('custGst').value.trim(),
    email: document.getElementById('custEmail').value.trim(),
    phone: document.getElementById('custPhone').value.trim(),
    address: document.getElementById('custAddress').value.trim(),
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Customer updated', 'success');
  } else {
    data.push({id: FB.uid('CUS'), balance:0, ...payload});
    FB.toast('Customer added', 'success');
  }
  FB.set(FB.KEYS.customers, data);
  bootstrap.Modal.getInstance(document.getElementById('customerModal')).hide();
  loadCustomers();
});

document.addEventListener('DOMContentLoaded', () => {
  loadCustomers();
  // Support deep links from Dashboard, e.g. customers.html?open=CUS-ABC123
  const openId = new URLSearchParams(window.location.search).get('open');
  if(openId) editCustomer(openId);
});
