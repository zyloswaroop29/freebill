/* =========================================================
   FreeBill ERP - notifications.js
   ========================================================= */

function renderNotifications(){
  const list = document.getElementById('notificationsList');
  const rows = FB.get(FB.KEYS.notifications, []);
  if(!rows.length){
    list.innerHTML = `<div class="glass-card empty-state"><i class="fa-solid fa-bell-slash d-block"></i>No notifications yet.</div>`;
    return;
  }
  const icon = {success:'fa-circle-check', warning:'fa-triangle-exclamation', danger:'fa-circle-xmark', info:'fa-circle-info'};
  list.innerHTML = rows.map(n => `
    <div class="glass-card p-3 d-flex align-items-start gap-3 ${n.read ? '' : 'notification-unread'}">
      <i class="fa-solid ${icon[n.type] || icon.info} mt-1"></i>
      <div class="flex-grow-1">
        <div class="fw-bold">${FB.escapeHtml(n.title || 'Notification')}</div>
        <div class="text-muted-c small">${FB.escapeHtml(n.message || '')}</div>
        <div class="text-muted-c small mt-1">${new Date(n.date || Date.now()).toLocaleString()}</div>
      </div>
    </div>`).join('');
}

document.getElementById('markAllReadBtn')?.addEventListener('click', () => {
  const rows = FB.get(FB.KEYS.notifications, []).map(n => ({...n, read:true}));
  FB.set(FB.KEYS.notifications, rows);
  renderNotifications();
  FB.toast('Notifications marked read', 'success');
});

document.addEventListener('DOMContentLoaded', renderNotifications);
