/* =========================================================
   FreeBill ERP — product.js
   ========================================================= */

let productTable;

function stockBadge(p){
  if(p.stock <= 0) return `<span class="badge-status badge-overdue">Out of Stock</span>`;
  if(p.stock <= p.lowStock) return `<span class="badge-status badge-pending">Low Stock</span>`;
  return `<span class="badge-status badge-paid">In Stock</span>`;
}

function loadProducts(){
  const data = FB.get(FB.KEYS.products, []);
  const tbody = document.querySelector('#productTable tbody');
  tbody.innerHTML = '';
  data.forEach(p => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${p.name}</td>
        <td>${p.sku}</td>
        <td>${p.category||'-'}</td>
        <td>${FB.money(p.price)}</td>
        <td>${p.stock}</td>
        <td>${stockBadge(p)}</td>
        <td class="row-actions">
          <button class="icon-btn" onclick="editProduct('${p.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deleteProduct('${p.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  if(productTable) productTable.destroy();
  productTable = $('#productTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search products...'} });
}

function openProductModal(){
  document.getElementById('productForm').reset();
  document.getElementById('prodId').value = '';
  document.getElementById('prodLowStock').value = 10;
  document.getElementById('productModalTitle').textContent = 'Add Product';
}

function editProduct(id){
  const data = FB.get(FB.KEYS.products, []);
  const p = data.find(x => x.id === id);
  if(!p) return;
  document.getElementById('productModalTitle').textContent = 'Edit Product';
  document.getElementById('prodId').value = p.id;
  document.getElementById('prodName').value = p.name;
  document.getElementById('prodSku').value = p.sku;
  document.getElementById('prodCategory').value = p.category||'';
  document.getElementById('prodPrice').value = p.price;
  document.getElementById('prodCost').value = p.cost||0;
  document.getElementById('prodStock').value = p.stock;
  document.getElementById('prodLowStock').value = p.lowStock||10;
  new bootstrap.Modal(document.getElementById('productModal')).show();
}

function deleteProduct(id){
  if(!confirm('Delete this product?')) return;
  let data = FB.get(FB.KEYS.products, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.products, data);
  loadProducts();
  FB.toast('Product deleted', 'info');
}

document.getElementById('productForm').addEventListener('submit', function(e){
  e.preventDefault();
  const id = document.getElementById('prodId').value;
  const data = FB.get(FB.KEYS.products, []);
  const payload = {
    name: document.getElementById('prodName').value.trim(),
    sku: document.getElementById('prodSku').value.trim(),
    category: document.getElementById('prodCategory').value.trim(),
    price: parseFloat(document.getElementById('prodPrice').value)||0,
    cost: parseFloat(document.getElementById('prodCost').value)||0,
    stock: parseInt(document.getElementById('prodStock').value)||0,
    lowStock: parseInt(document.getElementById('prodLowStock').value)||10,
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Product updated', 'success');
  } else {
    data.push({id: FB.uid('PRD'), ...payload});
    FB.toast('Product added', 'success');
  }
  FB.set(FB.KEYS.products, data);
  bootstrap.Modal.getInstance(document.getElementById('productModal')).hide();
  loadProducts();
});

document.addEventListener('DOMContentLoaded', () => {
  loadProducts();
  // Support deep links from Dashboard, e.g. products.html?open=PRD-ABC123
  const openId = new URLSearchParams(window.location.search).get('open');
  if(openId) editProduct(openId);
});
