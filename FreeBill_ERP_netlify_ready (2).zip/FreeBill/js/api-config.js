/* =========================================================
   FreeBill ERP — js/api-config.js
   Base URL of the backend (backend/server.js).

   IMPORTANT: Netlify (and most static-site hosts) only serve static
   files — they do NOT run backend/server.js for you. You must host the
   backend somewhere that runs a real Node process (Render, Railway,
   Fly.io, a VPS, etc.) and put that URL below. See backend/README.md.
   ========================================================= */
// TODO: After you deploy the backend on Render (see backend/README.md),
// replace the line below with your real Render URL, e.g.:
//   const FB_API_BASE = 'https://freebill-backend.onrender.com/api';
const FB_API_BASE = 'https://freebill-backend.onrender.com/api';
// While developing locally, this override kicks in automatically:
const FB_API_BASE_RESOLVED = (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
  ? 'http://localhost:5000/api'
  : FB_API_BASE;

async function fbApi(path, { method = 'GET', body, auth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = localStorage.getItem('fb_token');
    if (token) headers.Authorization = `Bearer ${token}`;
  }
  let res;
  try {
    res = await fetch(`${FB_API_BASE_RESOLVED}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    });
  } catch (err) {
    throw new Error(`Could not reach the backend at ${FB_API_BASE_RESOLVED}. Is it deployed and running? (see js/api-config.js)`);
  }

  // A static host with no real backend at this URL will often still return
  // 200 with an HTML fallback page instead of JSON — don't mistake that
  // for a successful API response.
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error(
      `Got a non-JSON response from ${FB_API_BASE_RESOLVED}${path} (status ${res.status}). ` +
      `This usually means FB_API_BASE in js/api-config.js isn't pointing at a real running backend.`
    );
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.data = data;
    err.status = res.status;
    throw err;
  }
  return data;
}
