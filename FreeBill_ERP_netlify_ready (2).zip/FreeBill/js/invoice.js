/* =========================================================
   FreeBill ERP - invoice.js
   ========================================================= */

let invoiceTable;
const badgeClassMap = {paid:'badge-paid', pending:'badge-pending', overdue:'badge-overdue', draft:'badge-draft'};

function loadInvoices(){
  const data = FB.get(FB.KEYS.invoices, []);
  const tbody = document.querySelector('#invoiceTable tbody');
  tbody.innerHTML = '';
  data.forEach(inv => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${FB.escapeHtml(inv.number)}</td>
        <td>${FB.escapeHtml(inv.customer)}</td>
        <td>${FB.escapeHtml(inv.date)}</td>
        <td>${FB.escapeHtml(inv.dueDate || '-')}</td>
        <td>${FB.money(inv.amount)}</td>
        <td><span class="badge-status ${badgeClassMap[inv.status] || 'badge-draft'}">${FB.escapeHtml(inv.status)}</span></td>
        <td class="row-actions">
          <button class="icon-btn" onclick="downloadInvoicePdf('${inv.id}')" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></button>
          <button class="icon-btn" onclick="editInvoice('${inv.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deleteInvoice('${inv.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  if(invoiceTable) invoiceTable.destroy();
  invoiceTable = $('#invoiceTable').DataTable({ pageLength: 8, lengthChange:false, order:[[2,'desc']], language:{search:'', searchPlaceholder:'Search invoices...'} });
}

function populateCustomerSelect(){
  const sel = document.getElementById('invCustomer');
  const customers = FB.get(FB.KEYS.customers, []);
  sel.innerHTML = customers.map(c => `<option value="${FB.escapeHtml(c.name)}">${FB.escapeHtml(c.name)} (${FB.escapeHtml(c.company || '-')})</option>`).join('');
}

function productOptionsHtml(){
  const products = FB.get(FB.KEYS.products, []);
  return '<option value="">Select product...</option>' +
    products.map(p => `<option value="${p.id}" data-price="${p.price}" data-hsn="${FB.escapeHtml(p.hsn || '')}" data-gst="${p.gstRate ?? ''}" data-unit="${FB.escapeHtml(p.unit || 'NOS')}">${FB.escapeHtml(p.name)}</option>`).join('');
}

function addInvoiceItemRow(qtyVal=1, priceVal='', productId='', hsnVal='', gstVal='', unitVal='NOS', nameVal=''){
  const tpl = document.getElementById('invItemRowTpl');
  const clone = tpl.content.cloneNode(true);
  const row = clone.querySelector('.inv-item-row');
  const sel = row.querySelector('.item-product');
  sel.innerHTML = productOptionsHtml();
  if(productId) sel.value = productId;
  const selected = sel.options[sel.selectedIndex];
  row.querySelector('.item-name').value = nameVal || (selected?.text && selected.value ? selected.text : '');
  row.querySelector('.item-hsn').value = hsnVal || selected?.dataset?.hsn || '';
  row.querySelector('.item-gst').value = gstVal || selected?.dataset?.gst || (FB.get(FB.KEYS.settings, {}).taxRate ?? 0);
  row.querySelector('.item-unit').value = unitVal || selected?.dataset?.unit || 'NOS';
  row.querySelector('.item-qty').value = qtyVal;
  row.querySelector('.item-price').value = priceVal;

  sel.addEventListener('change', () => {
    const opt = sel.options[sel.selectedIndex];
    row.querySelector('.item-price').value = opt?.dataset?.price || 0;
    row.querySelector('.item-name').value = opt?.value ? opt.text : '';
    row.querySelector('.item-hsn').value = opt?.dataset?.hsn || '';
    row.querySelector('.item-gst').value = opt?.dataset?.gst || (FB.get(FB.KEYS.settings, {}).taxRate ?? 0);
    row.querySelector('.item-unit').value = opt?.dataset?.unit || 'NOS';
    recalcInvoiceTotals();
  });
  row.querySelector('.item-gst').addEventListener('input', recalcInvoiceTotals);
  row.querySelector('.item-name').addEventListener('input', recalcInvoiceTotals);
  row.querySelector('.item-qty').addEventListener('input', recalcInvoiceTotals);
  row.querySelector('.item-price').addEventListener('input', recalcInvoiceTotals);

  document.getElementById('invItemsWrap').appendChild(row);
  recalcInvoiceTotals();
}

function recalcInvoiceTotals(){
  let subtotal = 0;
  let tax = 0;
  document.querySelectorAll('.inv-item-row').forEach(row => {
    const qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    const price = parseFloat(row.querySelector('.item-price').value) || 0;
    const gstRate = parseFloat(row.querySelector('.item-gst').value) || 0;
    const lineTotal = qty * price;
    row.querySelector('.item-line-total').textContent = lineTotal.toFixed(2);
    subtotal += lineTotal;
    tax += lineTotal * (gstRate / 100);
  });
  document.getElementById('invSubtotal').textContent = FB.money(subtotal);
  document.getElementById('invTax').textContent = FB.money(tax);
  document.getElementById('invTotal').textContent = FB.money(subtotal + tax);
}

function openInvoiceModal(){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  document.getElementById('invoiceForm').reset();
  document.getElementById('invId').value = '';
  document.getElementById('invItemsWrap').innerHTML = '';
  populateCustomerSelect();
  const invoices = FB.get(FB.KEYS.invoices, []);
  document.getElementById('invNumber').value = FB.docNumber('invoice', invoices);
  document.getElementById('invDate').value = FB.todayISO();
  document.getElementById('invDueDate').value = FB.todayISO();
  addInvoiceItemRow();
  recalcInvoiceTotals();
  new bootstrap.Modal(document.getElementById('invoiceModal')).show();
}

function editInvoice(id){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const data = FB.get(FB.KEYS.invoices, []);
  const inv = data.find(x => x.id === id);
  if(!inv) return;
  populateCustomerSelect();
  document.getElementById('invId').value = inv.id;
  document.getElementById('invNumber').value = inv.number;
  document.getElementById('invCustomer').value = inv.customer;
  document.getElementById('invStatus').value = inv.status;
  document.getElementById('invDate').value = inv.date;
  document.getElementById('invDueDate').value = inv.dueDate || inv.date;
  document.getElementById('invItemsWrap').innerHTML = '';
  if(inv.items && inv.items.length) inv.items.forEach(it => addInvoiceItemRow(it.qty, it.price, it.productId, it.hsn, it.gstRate, it.unit, it.name || it.description));
  else addInvoiceItemRow(1, inv.amount);
  recalcInvoiceTotals();
  new bootstrap.Modal(document.getElementById('invoiceModal')).show();
}

function deleteInvoice(id){
  if(!confirm('Delete this invoice?')) return;
  let data = FB.get(FB.KEYS.invoices, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.invoices, data);
  loadInvoices();
  FB.toast('Invoice deleted', 'info');
}

document.getElementById('invoiceForm').addEventListener('submit', function(e){
  e.preventDefault();
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const id = document.getElementById('invId').value;
  const data = FB.get(FB.KEYS.invoices, []);
  const items = [];
  let subtotal = 0;
  let tax = 0;

  document.querySelectorAll('.inv-item-row').forEach(row => {
    const sel = row.querySelector('.item-product');
    const opt = sel.options[sel.selectedIndex];
    const qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    const price = parseFloat(row.querySelector('.item-price').value) || 0;
    const hsn = row.querySelector('.item-hsn').value.trim();
    const gstRate = parseFloat(row.querySelector('.item-gst').value) || 0;
    const unit = row.querySelector('.item-unit').value.trim() || 'NOS';
    if(qty > 0){
      items.push({ productId: sel.value, name: row.querySelector('.item-name').value.trim() || opt?.text || 'Item', hsn, gstRate, unit, qty, price });
      subtotal += qty * price;
      tax += qty * price * (gstRate / 100);
    }
  });

  const total = subtotal + tax;
  const payload = {
    number: document.getElementById('invNumber').value,
    customer: document.getElementById('invCustomer').value,
    status: document.getElementById('invStatus').value,
    date: document.getElementById('invDate').value,
    dueDate: document.getElementById('invDueDate').value,
    amount: Math.round(total * 100) / 100,
    subtotal: Math.round(subtotal * 100) / 100,
    tax: Math.round(tax * 100) / 100,
    items
  };

  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Invoice updated', 'success');
  } else {
    data.push({id: FB.uid('INV'), ...payload});
    FB.toast('Invoice created', 'success');
  }
  FB.set(FB.KEYS.invoices, data);
  bootstrap.Modal.getInstance(document.getElementById('invoiceModal')).hide();
  loadInvoices();
});

function addStoredImage(doc, imageData, x, y, w, h){
  if(!imageData) return;
  try{
    const type = imageData.includes('image/jpeg') ? 'JPEG' : 'PNG';
    doc.addImage(imageData, type, x, y, w, h);
  }catch(e){}
}

function downloadInvoicePdf(id){
  const data = FB.get(FB.KEYS.invoices, []);
  const inv = data.find(x => x.id === id);
  if(!inv) return;
  const settings = FB.get(FB.KEYS.settings, {});
  const customers = FB.get(FB.KEYS.customers, []);
  const customer = customers.find(c => c.name === inv.customer) || {};
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({unit:'mm', format:'a4'});
  const cur = settings.currency || 'RM';
  const items = (inv.items && inv.items.length) ? inv.items : [{name:'Service / Goods', hsn:'', gstRate:settings.taxRate || 0, unit:'NOS', qty:1, price: inv.subtotal || inv.amount}];
  const subtotal = items.reduce((sum, it) => sum + ((Number(it.qty)||0) * (Number(it.price)||0)), 0);
  const tax = items.reduce((sum, it) => sum + ((Number(it.qty)||0) * (Number(it.price)||0) * ((Number(it.gstRate)||0) / 100)), 0);
  const total = subtotal + tax;
  const money = (n) => `${cur} ${Number(n || 0).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}`;

  doc.setDrawColor(80); doc.setLineWidth(.25); doc.rect(5, 5, 200, 282);
  addStoredImage(doc, settings.logoData, 10, 10, 28, 22);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(22); doc.setTextColor(0, 83, 92);
  doc.text(settings.companyName || 'FreeBill ERP', settings.logoData ? 42 : 10, 19);
  doc.setFontSize(9); doc.setFont('helvetica', 'normal'); doc.setTextColor(40);
  doc.text(settings.tagline || '', settings.logoData ? 42 : 10, 26, {maxWidth:78});
  doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(20);
  doc.text(settings.companyName || 'FreeBill ERP', 198, 12, {align:'right'});
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
  doc.text(doc.splitTextToSize(settings.address || '', 82), 198, 18, {align:'right'});
  doc.text(`Contact : ${settings.phone || ''}`, 198, 33, {align:'right'});
  doc.text(`E-mail : ${settings.email || ''}  Website : ${settings.website || ''}`, 198, 38, {align:'right'});
  doc.setFont('helvetica', 'bold'); doc.text(`GSTIN : ${settings.gst || ''}`, 198, 43, {align:'right'});
  doc.line(5, 48, 205, 48);
  doc.setFontSize(8.5); doc.text('Office Address:', 7, 53);
  doc.setFont('helvetica', 'normal'); doc.text(doc.splitTextToSize(settings.officeAddress || settings.address || '', 158), 33, 53);
  doc.line(5, 58, 205, 58);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.text(settings.invoiceTitle || 'GST INVOICE', 105, 55.5, {align:'center'});
  doc.line(5, 63, 205, 63);

  doc.setFontSize(9); doc.text('Billing Address,', 8, 69);
  doc.text(inv.customer || '', 8, 75);
  doc.setFont('helvetica', 'normal'); doc.text(doc.splitTextToSize(customer.address || '', 90), 8, 81);
  doc.setFont('helvetica', 'bold'); doc.text('GSTIN :', 8, 96);
  doc.line(105, 63, 105, 105);
  [['Invoice No', inv.number], ['Invoice Date', inv.date], ['State of Supply', settings.stateOfSupply || '-'], ['P.O. No. / Date', '-'], ['E-way Bill', '-']].forEach((row, idx) => {
    const yy = 69 + (idx * 8);
    doc.text(row[0], 110, yy); doc.text(':', 154, yy); doc.text(String(row[1]), 198, yy, {align:'right'});
  });
  doc.line(5, 105, 205, 105);

  doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5);
  [['SL', 9], ['DESCRIPTION OF GOODS', 57], ['HSN/SAC', 113], ['GST %', 126], ['UNIT', 139], ['QTY', 156], ['RATE', 178], ['AMOUNT', 202]]
    .forEach(([label, x]) => doc.text(label, x, 112, {align: label === 'DESCRIPTION OF GOODS' ? 'center' : 'right'}));
  doc.line(5, 107, 205, 107); doc.line(5, 116, 205, 116);
  [13, 100, 116, 128, 140, 158, 180].forEach(x => doc.line(x, 107, x, 205));

  let y = 123;
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5);
  items.forEach((it, idx) => {
    const amount = (Number(it.qty)||0) * (Number(it.price)||0);
    doc.text(String(idx + 1), 9, y, {align:'center'});
    doc.setFont('helvetica', 'bold'); doc.text(String(it.name || 'Item').slice(0, 42), 16, y);
    doc.setFont('helvetica', 'normal');
    doc.text(String(it.hsn || ''), 113, y, {align:'right'});
    doc.text(`${Number(it.gstRate || 0)}%`, 126, y, {align:'right'});
    doc.text(String(it.unit || 'NOS'), 139, y, {align:'right'});
    doc.text(Number(it.qty || 0).toFixed(2), 156, y, {align:'right'});
    doc.text(Number(it.price || 0).toFixed(2), 178, y, {align:'right'});
    doc.text(Number(amount || 0).toFixed(2), 202, y, {align:'right'});
    y += 8;
  });
  doc.line(5, 205, 205, 205);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
  doc.text('SUMMARY', 7, 212); doc.text('TAXABLE', 55, 212); doc.text('TAX', 85, 212);
  doc.setFont('helvetica', 'normal'); doc.text('GST', 7, 219); doc.text(Number(subtotal).toFixed(2), 68, 219, {align:'right'}); doc.text(Number(tax).toFixed(2), 96, 219, {align:'right'});
  doc.setFont('helvetica', 'bold');
  [['TOTAL BEFORE TAX', subtotal], ['TOTAL TAX AMOUNT', tax], ['ROUND OFF', Math.round(total) - total], ['TOTAL AMOUNT', Math.round(total)]].forEach((row, idx) => {
    const yy = 211 + (idx * 8);
    doc.text(row[0], 110, yy); doc.text(money(row[1]), 202, yy, {align:'right'}); doc.line(105, yy + 3, 205, yy + 3);
  });
  doc.line(5, 230, 205, 230);
  doc.setFontSize(8.5); doc.text('Company Bank Details:', 9, 237);
  doc.setFont('helvetica', 'normal');
  doc.text(`Account No : ${settings.bankAccountNo || ''}`, 9, 244);
  doc.text(`IFSC : ${settings.bankIfsc || ''}`, 9, 251);
  doc.text(`Account Name : ${settings.bankAccountName || ''}`, 76, 244);
  doc.text(`Bank Name & Branch : ${settings.bankNameBranch || ''}`, 76, 251);
  if(settings.qrData){ doc.setFont('helvetica', 'bold'); doc.text('SCAN & PAY', 188, 237, {align:'center'}); addStoredImage(doc, settings.qrData, 176, 241, 22, 22); }
  doc.line(5, 266, 205, 266);
  doc.setFont('helvetica', 'bold'); doc.text('Terms and Conditions', 8, 272);
  doc.setFont('helvetica', 'normal'); doc.text(doc.splitTextToSize(settings.terms || '', 92), 8, 277);
  doc.line(100, 266, 100, 287); doc.line(145, 266, 145, 287);
  doc.setFont('helvetica', 'bold'); doc.text(`For ${settings.companyName || 'FreeBill ERP'}`, 173, 272, {align:'center'});
  addStoredImage(doc, settings.signatureData, 157, 274, 32, 9);
  doc.text("Receiver's Signature / Seal", 122, 284, {align:'center'});
  doc.text('Authorised Signature', 174, 284, {align:'center'});
  doc.setFontSize(8); doc.text(settings.footerNote || 'Generated by FreeBill ERP', 105, 294, {align:'center'});

  doc.save(`${inv.number}.pdf`);
  FB.toast('PDF downloaded', 'success');
}

document.addEventListener('DOMContentLoaded', () => {
  loadInvoices();
  // Support deep links from Dashboard, e.g. invoice.html?open=INV-ABC123
  const openId = new URLSearchParams(window.location.search).get('open');
  if(openId) editInvoice(openId);
});
