/* =========================================================
   FreeBill ERP - admin.js (User Management)
   ========================================================= */

let adminUsersTable;

function statusLabel(user){
  const status = user.status || 'active';
  if(status === 'hold') return {text:'On Hold', cls:'badge-overdue'};
  if(FB.isExpired(user)) return {text:'Expired', cls:'badge-overdue'};
  return {text:'Active', cls:'badge-paid'};
}

function renderAdmin(){
  FB.requireAdmin();
  const users = FB.get(FB.KEYS.users, []);
  const collections = {
    adminUsersCount: users,
    adminCustomersCount: FB.get(FB.KEYS.customers, []),
    adminInvoicesCount: FB.get(FB.KEYS.invoices, []),
    adminProductsCount: FB.get(FB.KEYS.products, [])
  };

  Object.entries(collections).forEach(([id, rows]) => {
    const el = document.getElementById(id);
    if(el) el.textContent = rows.length;
  });

  const tbody = document.querySelector('#adminUsersTable tbody');
  tbody.innerHTML = '';
  users.forEach((user, idx) => {
    const role = user.role || 'user';
    const isAdminUser = role === 'admin';
    const s = statusLabel(user);
    const held = (user.status || 'active') === 'hold';
    const pending = user.pendingPayment;
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${FB.escapeHtml(user.name || '-')}</td>
        <td>${FB.escapeHtml(user.username || user.email || '-')}</td>
        <td>${FB.escapeHtml(user.email || '-')}</td>
        <td>${FB.escapeHtml(user.company || '-')}</td>
        <td><span class="badge-status ${isAdminUser ? 'badge-paid' : 'badge-draft'}">${FB.escapeHtml(role)}</span></td>
        <td>
          <span class="badge-status ${s.cls}">${s.text}</span>
          ${pending ? `<div class="small text-muted-c mt-1">${FB.escapeHtml(pending.planName)} payment pending Rs. ${Number(pending.amount || 0).toLocaleString('en-IN')}</div>` : ''}
        </td>
        <td>
          <input type="date" class="form-control form-control-sm subscription-date" style="min-width:150px" value="${user.expiryDate || ''}"
            onchange="setUserExpiry(${idx}, this.value)">
        </td>
        <td class="row-actions">
          ${isAdminUser ? '<span class="text-muted-c small">—</span>' : `
          <button class="icon-btn" title="${held ? 'Unhold account' : 'Hold account'}" onclick="toggleHoldUser(${idx})">
            <i class="fa-solid ${held ? 'fa-lock-open' : 'fa-lock'}"></i>
          </button>
          <button class="icon-btn" title="Delete account" onclick="deleteUser(${idx})"><i class="fa-solid fa-trash text-danger"></i></button>
          `}
        </td>
      </tr>`);
  });

  if(adminUsersTable) adminUsersTable.destroy();
  adminUsersTable = $('#adminUsersTable').DataTable({pageLength:8, lengthChange:false, language:{search:'', searchPlaceholder:'Search users...'}});
}

function toggleHoldUser(idx){
  const users = FB.get(FB.KEYS.users, []);
  const user = users[idx];
  if(!user || user.role === 'admin') return;
  const held = (user.status || 'active') === 'hold';
  if(!confirm(held ? `Unhold ${user.name}'s account?` : `Put ${user.name}'s account on hold? All sections will be blocked for this user until unheld.`)) return;
  user.status = held ? 'active' : 'hold';
  FB.set(FB.KEYS.users, users);
  FB.toast(held ? 'Account unheld' : 'Account put on hold', held ? 'success' : 'warning');
  renderAdmin();
}

function deleteUser(idx){
  const users = FB.get(FB.KEYS.users, []);
  const user = users[idx];
  if(!user || user.role === 'admin') return;
  if(!confirm(`Delete ${user.name}'s account permanently? This cannot be undone.`)) return;
  users.splice(idx, 1);
  FB.set(FB.KEYS.users, users);
  FB.toast('User account deleted', 'info');
  renderAdmin();
}

function setUserExpiry(idx, value){
  const users = FB.get(FB.KEYS.users, []);
  const user = users[idx];
  if(!user) return;
  user.expiryDate = value || '';
  if(value && user.pendingPayment){
    user.planName = user.pendingPayment.planName || user.planName || 'Paid Plan';
    user.lastPlanAmount = user.pendingPayment.amount;
    user.lastPaymentUpi = user.pendingPayment.upi;
    user.pendingPayment = null;
    user.status = 'active';
  }
  FB.set(FB.KEYS.users, users);
  FB.notify('Subscription date updated', `${user.name || user.email}'s subscription is valid until ${value || 'not set'}.`, 'success');
  FB.toast('Subscription date updated', 'success');
  renderAdmin();
}

document.getElementById('adminAddUserForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  const name = document.getElementById('newUserName').value.trim();
  const email = document.getElementById('newUserEmail').value.trim().toLowerCase();
  const username = document.getElementById('newUserUsername').value.trim() || email;
  const password = document.getElementById('newUserPassword').value;
  const company = document.getElementById('newUserCompany').value.trim();
  const expiryDate = document.getElementById('newUserExpiry').value || FB.addDaysISO(7);

  const users = FB.get(FB.KEYS.users, []);
  if(users.some(u => (u.email || '').toLowerCase() === email)){
    FB.toast('A user with this email already exists', 'danger');
    return;
  }
  users.push({name, email, username, password, company, role:'user', status:'active', expiryDate, trialStartedAt:FB.todayISO(), planName:'1 Week Free Trial'});
  FB.set(FB.KEYS.users, users);
  FB.toast('User account created', 'success');
  document.getElementById('adminAddUserForm').reset();
  bootstrap.Modal.getInstance(document.getElementById('adminAddUserModal'))?.hide();
  renderAdmin();
});

document.addEventListener('DOMContentLoaded', renderAdmin);
