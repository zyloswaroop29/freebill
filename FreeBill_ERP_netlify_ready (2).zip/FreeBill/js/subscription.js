/* =========================================================
   FreeBill ERP - subscription.js
   ========================================================= */

function currentUserIndex(users, session){
  const key = (session.username || session.email || '').toLowerCase();
  return users.findIndex(u => (u.username || '').toLowerCase() === key || (u.email || '').toLowerCase() === key);
}

function loadSubscription(){
  const session = FB.get(FB.KEYS.session, {});
  const user = FB.findLiveUser(session) || session;
  const daysLeft = FB.daysUntil(user.expiryDate);
  document.getElementById('subPlanName').textContent = FB.planLabel(user);
  document.getElementById('subDaysLeft').textContent = daysLeft;
  document.getElementById('subExpiryDate').textContent = user.expiryDate || '-';
  document.getElementById('expiredNotice').classList.toggle('d-none', daysLeft > 0);
}

let pendingPlan = null;
const PAYMENT_UPI = 'swaroopsandy513-1@oksbi';

function buildUpiUrl(plan){
  const params = new URLSearchParams({
    pa: PAYMENT_UPI,
    pn: 'FreeBill ERP',
    am: String(plan.amount),
    cu: 'INR',
    tn: `${plan.name} Plan activation`
  });
  return `upi://pay?${params.toString()}`;
}

function startPlanPayment(name, days, amount){
  pendingPlan = {name, days, amount};
  document.getElementById('payPlanName').textContent = `${name} Plan`;
  document.getElementById('payPlanAmount').textContent = `Rs. ${Number(amount).toLocaleString('en-IN')}`;
  const payBtn = document.getElementById('openUpiPayBtn');
  payBtn.href = buildUpiUrl(pendingPlan);
  payBtn.onclick = () => {
    FB.toast('Opening GPay / UPI payment app...', 'info');
    markPaymentPending(pendingPlan);
    return true;
  };
  new bootstrap.Modal(document.getElementById('paymentModal')).show();
}

function markPaymentPending(plan){
  const session = FB.get(FB.KEYS.session, {});
  const users = FB.get(FB.KEYS.users, []);
  const idx = currentUserIndex(users, session);
  if(idx < 0) return;
  users[idx].pendingPayment = {
    planName: `${plan.name} Plan`,
    days: plan.days,
    amount: plan.amount,
    upi: PAYMENT_UPI,
    status: 'pending_admin_verification',
    requestedAt: new Date().toISOString()
  };
  FB.set(FB.KEYS.users, users);
  FB.notify('Payment pending verification', `${users[idx].name || users[idx].email} opened payment for ${plan.name} Plan - Rs. ${plan.amount}.`, 'warning');
}

function activatePlan(name, days, amount){
  const session = FB.get(FB.KEYS.session, {});
  const users = FB.get(FB.KEYS.users, []);
  const idx = currentUserIndex(users, session);
  if(idx < 0){ FB.toast('Account not found', 'danger'); return; }
  const currentDays = FB.daysUntil(users[idx].expiryDate);
  const startDays = currentDays > 0 ? currentDays : 0;
  users[idx].expiryDate = FB.addDaysISO(startDays + days);
  users[idx].planName = `${name} Plan`;
  users[idx].lastPlanAmount = amount;
  users[idx].lastPlanCurrency = 'INR';
  users[idx].lastPaymentUpi = PAYMENT_UPI;
  users[idx].lastPaymentMarkedAt = new Date().toISOString();
  users[idx].status = 'active';
  FB.set(FB.KEYS.users, users);
  FB.set(FB.KEYS.session, {...session, name:users[idx].name, company:users[idx].company, role:users[idx].role || 'user'});
  FB.toast(`${name} plan activated for Rs. ${amount}`, 'success');
  loadSubscription();
}

document.addEventListener('DOMContentLoaded', () => {
  loadSubscription();
});
