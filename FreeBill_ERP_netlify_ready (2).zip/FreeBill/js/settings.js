/* =========================================================
   FreeBill ERP — settings.js
   ========================================================= */

function loadSettingsForm(){
  const s = FB.get(FB.KEYS.settings, {});
  document.getElementById('setCompanyName').value = s.companyName || '';
  document.getElementById('setTagline').value = s.tagline || '';
  document.getElementById('setGst').value = s.gst || '';
  document.getElementById('setPhone').value = s.phone || '';
  document.getElementById('setEmail').value = s.email || '';
  document.getElementById('setWebsite').value = s.website || '';
  document.getElementById('setAddress').value = s.address || '';
  document.getElementById('setOfficeAddress').value = s.officeAddress || '';
  document.getElementById('setCurrency').value = s.currency || 'RM';
  document.getElementById('setTaxRate').value = s.taxRate ?? 6;
  document.getElementById('setInvoiceTitle').value = s.invoiceTitle || 'GST INVOICE';
  document.getElementById('setStateOfSupply').value = s.stateOfSupply || '';
  document.getElementById('setBankAccountNo').value = s.bankAccountNo || '';
  document.getElementById('setBankIfsc').value = s.bankIfsc || '';
  document.getElementById('setBankAccountName').value = s.bankAccountName || '';
  document.getElementById('setBankNameBranch').value = s.bankNameBranch || '';
  document.getElementById('setTerms').value = s.terms || '';
  document.getElementById('setFooterNote').value = s.footerNote || '';
  const prefixes = s.docPrefixes || {};
  document.getElementById('setPrefixInvoice').value = prefixes.invoice || 'INV';
  document.getElementById('setPrefixQuotation').value = prefixes.quotation || 'QUO';
  document.getElementById('setPrefixPurchase').value = prefixes.purchase || 'PO';
  document.getElementById('setPrefixDelivery').value = prefixes.delivery || 'DO';
  setPreview('logoPreview', s.logoData);
  setPreview('qrPreview', s.qrData);
  setPreview('signaturePreview', s.signatureData);

  document.getElementById('settingsDarkToggle').checked = document.body.classList.contains('dark-mode');
}

function setPreview(id, data){
  const img = document.getElementById(id);
  img.src = data || '';
  img.style.visibility = data ? 'visible' : 'hidden';
}

function readImageFile(input, key, previewId){
  const file = input.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const settings = FB.get(FB.KEYS.settings, {});
    settings[key] = reader.result;
    FB.set(FB.KEYS.settings, settings);
    setPreview(previewId, reader.result);
    FB.toast('Image uploaded', 'success');
  };
  reader.readAsDataURL(file);
}

document.getElementById('settingsForm').addEventListener('submit', function(e){
  e.preventDefault();
  const existing = FB.get(FB.KEYS.settings, {});
  const payload = {
    ...existing,
    companyName: document.getElementById('setCompanyName').value.trim(),
    tagline: document.getElementById('setTagline').value.trim(),
    gst: document.getElementById('setGst').value.trim(),
    phone: document.getElementById('setPhone').value.trim(),
    email: document.getElementById('setEmail').value.trim(),
    website: document.getElementById('setWebsite').value.trim(),
    address: document.getElementById('setAddress').value.trim(),
    officeAddress: document.getElementById('setOfficeAddress').value.trim(),
    currency: document.getElementById('setCurrency').value.trim() || 'RM',
    taxRate: parseFloat(document.getElementById('setTaxRate').value) || 0,
    invoiceTitle: document.getElementById('setInvoiceTitle').value.trim() || 'GST INVOICE',
    stateOfSupply: document.getElementById('setStateOfSupply').value.trim(),
    bankAccountNo: document.getElementById('setBankAccountNo').value.trim(),
    bankIfsc: document.getElementById('setBankIfsc').value.trim(),
    bankAccountName: document.getElementById('setBankAccountName').value.trim(),
    bankNameBranch: document.getElementById('setBankNameBranch').value.trim(),
    terms: document.getElementById('setTerms').value.trim(),
    footerNote: document.getElementById('setFooterNote').value.trim(),
    docPrefixes: {
      invoice: (document.getElementById('setPrefixInvoice').value.trim() || 'INV').toUpperCase(),
      quotation: (document.getElementById('setPrefixQuotation').value.trim() || 'QUO').toUpperCase(),
      purchase: (document.getElementById('setPrefixPurchase').value.trim() || 'PO').toUpperCase(),
      delivery: (document.getElementById('setPrefixDelivery').value.trim() || 'DO').toUpperCase(),
    },
  };
  FB.set(FB.KEYS.settings, payload);
  FB.toast('Settings saved', 'success');
});

document.getElementById('setLogoFile').addEventListener('change', function(){ readImageFile(this, 'logoData', 'logoPreview'); });
document.getElementById('setQrFile').addEventListener('change', function(){ readImageFile(this, 'qrData', 'qrPreview'); });
document.getElementById('setSignatureFile').addEventListener('change', function(){ readImageFile(this, 'signatureData', 'signaturePreview'); });

document.getElementById('settingsDarkToggle').addEventListener('change', function(){
  document.body.classList.toggle('dark-mode', this.checked);
  localStorage.setItem(FB.KEYS.theme, this.checked ? 'dark' : 'light');
});

document.getElementById('backupBtn').addEventListener('click', () => {
  const backup = {};
  Object.values(FB.KEYS).forEach(k => { if(k !== FB.KEYS.session) backup[k] = FB.get(k); });
  const blob = new Blob([JSON.stringify(backup, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `freebill_backup_${FB.todayISO()}.json`;
  a.click();
  FB.toast('Backup downloaded', 'success');
});

document.getElementById('restoreInput').addEventListener('change', function(e){
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const backup = JSON.parse(reader.result);
      Object.entries(backup).forEach(([k,v]) => FB.set(k, v));
      FB.toast('Data restored. Reloading...', 'success');
      setTimeout(() => window.location.reload(), 800);
    }catch(err){ FB.toast('Invalid backup file', 'danger'); }
  };
  reader.readAsText(file);
});

document.getElementById('resetBtn').addEventListener('click', () => {
  if(!confirm('This will erase all data and restore demo defaults. Continue?')) return;
  Object.values(FB.KEYS).forEach(k => { if(k !== FB.KEYS.session) localStorage.removeItem(k); });
  FB.seed();
  FB.toast('Data reset to defaults', 'success');
  setTimeout(() => window.location.reload(), 800);
});

document.addEventListener('DOMContentLoaded', loadSettingsForm);
