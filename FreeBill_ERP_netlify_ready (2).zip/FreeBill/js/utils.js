/* =========================================================
   FreeBill ERP — utils.js
   Browser backend data layer
   ========================================================= */

const FB = (() => {

  const KEYS = {
    session: 'fb_session',
    users: 'fb_users',
    customers: 'fb_customers',
    suppliers: 'fb_suppliers',
    products: 'fb_products',
    quotations: 'fb_quotations',
    invoices: 'fb_invoices',
    purchases: 'fb_purchases',
    deliveries: 'fb_deliveries',
    settings: 'fb_settings',
    theme: 'fb_theme',
    pendingOtp: 'fb_pending_otp',
    notifications: 'fb_notifications'
  };

  function get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : (fallback ?? null);
    }catch(e){ return fallback ?? null; }
  }
  function set(key, value){ localStorage.setItem(key, JSON.stringify(value)); }
  function uid(prefix='ID'){ return prefix + '-' + Math.random().toString(36).slice(2,8).toUpperCase(); }
  function money(n){
    const cur = (get(KEYS.settings, {}).currency) || 'RM';
    return cur + ' ' + Number(n || 0).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
  }
  function todayISO(){ return new Date().toISOString().slice(0,10); }
  function addDaysISO(days){
    const d = new Date();
    d.setDate(d.getDate() + Number(days || 0));
    return d.toISOString().slice(0,10);
  }
  function daysUntil(dateValue){
    if(!dateValue) return 0;
    const today = new Date();
    today.setHours(0,0,0,0);
    const end = new Date(dateValue + 'T00:00:00');
    const diff = Math.ceil((end - today) / 86400000);
    return Math.max(0, diff);
  }
  function isAdmin(){
    const s = get(KEYS.session);
    return s?.role === 'admin';
  }
  function requireAdmin(){
    const s = requireAuth();
    if(!s?.role || s.role !== 'admin'){
      window.location.href = (location.pathname.includes('/pages/') ? '../dashboard.html' : 'dashboard.html');
      return null;
    }
    return s;
  }

  // ---- Live account status (hold / delete / subscription expiry) ----
  const CONTACT_EMAIL = 'swaroop29@icloud.com';

  function findLiveUser(session){
    if(!session) return null;
    const users = get(KEYS.users, []);
    const idKey = (session.username || session.email || '').toLowerCase();
    return users.find(u => (u.username || '').toLowerCase() === idKey || (u.email || '').toLowerCase() === idKey) || null;
  }

  function isExpired(user){
    if(!user || !user.expiryDate) return false;
    return new Date(user.expiryDate + 'T00:00:00') <= new Date();
  }
  function planLabel(user){
    if(!user) return 'Free Trial';
    if(user.pendingPayment) return `${user.pendingPayment.planName || 'Plan'} - Pending Admin Verification`;
    if(user.planName) return user.planName;
    if(user.expiryDate) return '1 Week Free Trial';
    return 'Free Trial';
  }

  // Returns null if the account is fine, or a lock descriptor {reason, message} if blocked.
  function accountLockStatus(){
    const session = get(KEYS.session);
    if(!session) return null;
    if(session.role === 'admin') return null; // admin account is never locked
    const user = findLiveUser(session);
    if(!user){
      return {reason:'deleted', message:`Your account no longer exists. Please contact us at ${CONTACT_EMAIL}.`};
    }
    if((user.status || 'active') === 'hold'){
      return {reason:'hold', message:`Your account has been put on hold by the administrator. Please contact us at ${CONTACT_EMAIL} to unhold your account.`};
    }
    if(isExpired(user)){
      return {reason:'expired', message:'Your free trial or subscription has expired. Choose a plan to continue creating documents.'};
    }
    return null;
  }

  function requireActiveSubscriptionForDocuments(){
    const lock = accountLockStatus();
    if(!lock) return true;
    if(lock.reason === 'expired'){
      toast('Your trial or subscription has ended. Please activate a plan first.', 'warning');
      setTimeout(() => {
        window.location.href = location.pathname.includes('/pages/') ? 'subscription.html' : 'pages/subscription.html';
      }, 700);
      return false;
    }
    toast(lock.message, 'danger');
    return false;
  }

  function contactEmail(){ return CONTACT_EMAIL; }

  // ---- Document number prefix helper ----
  function docNumber(type, existingList){
    const prefixes = get(KEYS.settings, {}).docPrefixes || {};
    const defaults = {invoice:'INV', quotation:'QUO', purchase:'PO', delivery:'DO'};
    const prefix = (prefixes[type] || defaults[type] || 'DOC').trim().toUpperCase();
    return prefix + '-' + (1000 + (existingList?.length || 0) + 1);
  }
  function escapeHtml(value=''){
    return String(value).replace(/[&<>"']/g, ch => ({
      '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
    }[ch]));
  }

  function toast(msg, type='success'){
    const icons = {success:'fa-circle-check', danger:'fa-circle-xmark', warning:'fa-triangle-exclamation', info:'fa-circle-info'};
    const colors = {success:'#10B981', danger:'#EF4444', warning:'#F59E0B', info:'#2563EB'};
    let wrap = document.querySelector('.fb-toast-wrap');
    if(!wrap){
      wrap = document.createElement('div');
      wrap.className = 'fb-toast-wrap';
      wrap.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2000;display:flex;flex-direction:column;gap:10px;';
      document.body.appendChild(wrap);
    }
    const el = document.createElement('div');
    el.className = 'glass-card';
    el.style.cssText = `padding:.85rem 1.1rem;min-width:260px;display:flex;align-items:center;gap:.6rem;border-left:4px solid ${colors[type]};animation:fbIn .25s ease;`;
    el.innerHTML = `<i class="fa-solid ${icons[type]}" style="color:${colors[type]}"></i><span style="font-size:.9rem;font-weight:500">${msg}</span>`;
    wrap.appendChild(el);
    setTimeout(()=>{ el.style.transition='opacity .3s ease'; el.style.opacity='0'; setTimeout(()=>el.remove(),300); }, 3000);
  }

  function calcItems(items=[]){
    const rows = (items || []).filter(it => String(it.name || it.description || '').trim() || Number(it.qty) || Number(it.price));
    const subtotal = rows.reduce((s, it) => s + ((Number(it.qty) || 0) * (Number(it.price) || 0)), 0);
    const tax = rows.reduce((s, it) => s + ((Number(it.qty) || 0) * (Number(it.price) || 0) * ((Number(it.gstRate) || 0) / 100)), 0);
    const total = Math.round((subtotal + tax) * 100) / 100;
    return {items: rows, subtotal: Math.round(subtotal * 100) / 100, tax: Math.round(tax * 100) / 100, total};
  }

  function notify(title, message, type='info'){
    const rows = get(KEYS.notifications, []);
    rows.unshift({id: uid('NOT'), title, message, type, date: new Date().toISOString(), read:false});
    set(KEYS.notifications, rows.slice(0, 80));
  }

  function downloadDocumentPdf(type, id){
    const typeMap = {
      invoice:{key:KEYS.invoices, title:'GST INVOICE', number:'Invoice No', date:'Invoice Date', party:'customer'},
      quotation:{key:KEYS.quotations, title:'QUOTATION', number:'Quotation No', date:'Quotation Date', party:'customer'},
      purchase:{key:KEYS.purchases, title:'PURCHASE ORDER', number:'P.O. No', date:'Order Date', party:'supplier'},
      delivery:{key:KEYS.deliveries, title:'DELIVERY ORDER', number:'D.O. No', date:'Ship Date', party:'customer'}
    };
    const meta = typeMap[type];
    if(!meta || !window.jspdf){ toast('PDF library is not ready', 'danger'); return; }
    const docData = get(meta.key, []).find(x => x.id === id);
    if(!docData){ toast('Document not found', 'danger'); return; }
    const settings = get(KEYS.settings, {});
    const customers = get(KEYS.customers, []);
    const suppliers = get(KEYS.suppliers, []);
    const partyName = docData[meta.party] || '-';
    const party = meta.party === 'supplier'
      ? suppliers.find(x => x.name === partyName) || {}
      : customers.find(x => x.name === partyName) || {};
    const totals = calcItems(docData.items && docData.items.length ? docData.items : [{name:docData.notes || 'Service / Goods', hsn:'', gstRate:settings.taxRate || 0, unit:'NOS', qty:1, price:docData.subtotal || docData.amount || 0}]);
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({unit:'mm', format:'a4'});
    const cur = settings.currency || 'Rs.';
    const fmt = n => `${cur} ${Number(n || 0).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2})}`;

    pdf.setDrawColor(70); pdf.setLineWidth(.25); pdf.rect(5, 5, 200, 287);
    if(settings.logoData){
      try{ pdf.addImage(settings.logoData, settings.logoData.includes('jpeg') ? 'JPEG' : 'PNG', 10, 10, 28, 22); }catch(e){}
    }
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(20); pdf.setTextColor(0, 83, 92);
    pdf.text(settings.companyName || 'FreeBill ERP', settings.logoData ? 42 : 10, 18);
    pdf.setFontSize(9); pdf.setFont('helvetica', 'normal'); pdf.setTextColor(40);
    pdf.text(settings.tagline || '', settings.logoData ? 42 : 10, 25, {maxWidth:86});
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(13); pdf.text(settings.companyName || 'FreeBill ERP', 198, 12, {align:'right'});
    pdf.setFont('helvetica', 'normal'); pdf.setFontSize(9);
    pdf.text(pdf.splitTextToSize(settings.address || '', 82), 198, 18, {align:'right'});
    pdf.text(`Contact : ${settings.phone || ''}`, 198, 33, {align:'right'});
    pdf.text(`E-mail : ${settings.email || ''}  Website : ${settings.website || ''}`, 198, 38, {align:'right'});
    pdf.setFont('helvetica', 'bold'); pdf.text(`GSTIN : ${settings.gst || ''}`, 198, 43, {align:'right'});
    pdf.line(5, 48, 205, 48);
    pdf.setFontSize(8.5); pdf.text('Office Address:', 7, 53);
    pdf.setFont('helvetica', 'normal'); pdf.text(pdf.splitTextToSize(settings.officeAddress || settings.address || '', 158), 33, 53);
    pdf.line(5, 58, 205, 58);
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(13); pdf.text(settings.invoiceTitle && type === 'invoice' ? settings.invoiceTitle : meta.title, 105, 55.5, {align:'center'});
    pdf.line(5, 63, 205, 63);

    pdf.setFontSize(9); pdf.text(meta.party === 'supplier' ? 'Supplier,' : 'Billing Address,', 8, 69);
    pdf.text(partyName, 8, 75);
    pdf.setFont('helvetica', 'normal'); pdf.text(pdf.splitTextToSize(party.address || '', 90), 8, 81);
    pdf.setFont('helvetica', 'bold'); pdf.text(`GSTIN : ${party.gst || ''}`, 8, 98);
    pdf.line(105, 63, 105, 105);
    [[meta.number, docData.number], [meta.date, docData.date], ['State of Supply', settings.stateOfSupply || '-'], ['Reference', docData.reference || docData.invoice || '-'], ['Status', docData.status || '-']].forEach((row, idx) => {
      const yy = 69 + (idx * 8);
      pdf.text(row[0], 110, yy); pdf.text(':', 154, yy); pdf.text(String(row[1] || '-'), 198, yy, {align:'right'});
    });
    pdf.line(5, 105, 205, 105);

    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(8.5);
    [['SL', 9], ['DESCRIPTION OF GOODS', 57], ['HSN/SAC', 113], ['GST %', 126], ['UNIT', 139], ['QTY', 156], ['RATE', 178], ['AMOUNT', 202]]
      .forEach(([label, x]) => pdf.text(label, x, 112, {align: label === 'DESCRIPTION OF GOODS' ? 'center' : 'right'}));
    pdf.line(5, 107, 205, 107); pdf.line(5, 116, 205, 116);
    [13, 100, 116, 128, 140, 158, 180].forEach(x => pdf.line(x, 107, x, 205));
    let y = 123;
    pdf.setFont('helvetica', 'normal'); pdf.setFontSize(8.4);
    totals.items.slice(0, 10).forEach((it, idx) => {
      const amount = (Number(it.qty)||0) * (Number(it.price)||0);
      pdf.text(String(idx + 1), 9, y, {align:'center'});
      pdf.setFont('helvetica', 'bold'); pdf.text(String(it.name || it.description || 'Item').slice(0, 42), 16, y);
      pdf.setFont('helvetica', 'normal');
      if(it.description) pdf.text(pdf.splitTextToSize(String(it.description).slice(0, 80), 78), 18, y + 5);
      pdf.text(String(it.hsn || ''), 113, y, {align:'right'});
      pdf.text(`${Number(it.gstRate || 0)}%`, 126, y, {align:'right'});
      pdf.text(String(it.unit || 'NOS'), 139, y, {align:'right'});
      pdf.text(Number(it.qty || 0).toFixed(2), 156, y, {align:'right'});
      pdf.text(Number(it.price || 0).toFixed(2), 178, y, {align:'right'});
      pdf.text(Number(amount || 0).toFixed(2), 202, y, {align:'right'});
      y += it.description ? 13 : 8;
    });
    pdf.line(5, 205, 205, 205);
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(9);
    pdf.text('SUMMARY', 7, 212); pdf.text('TAXABLE', 55, 212); pdf.text('TAX', 90, 212);
    pdf.setFont('helvetica', 'normal'); pdf.text('GST', 7, 219); pdf.text(Number(totals.subtotal).toFixed(2), 68, 219, {align:'right'}); pdf.text(Number(totals.tax).toFixed(2), 100, 219, {align:'right'});
    pdf.setFont('helvetica', 'bold');
    [['TOTAL BEFORE TAX', totals.subtotal], ['TOTAL TAX AMOUNT', totals.tax], ['ROUND OFF', Math.round(totals.total) - totals.total], ['TOTAL AMOUNT', Math.round(totals.total)]].forEach((row, idx) => {
      const yy = 211 + (idx * 8);
      pdf.text(row[0], 110, yy); pdf.text(fmt(row[1]), 202, yy, {align:'right'}); pdf.line(105, yy + 3, 205, yy + 3);
    });
    pdf.line(5, 230, 205, 230);
    pdf.setFontSize(8.5); pdf.text("Company's Bank Details:", 9, 237);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Account No : ${settings.bankAccountNo || ''}`, 9, 244);
    pdf.text(`IFSC : ${settings.bankIfsc || ''}`, 9, 251);
    pdf.text(`Account Name : ${settings.bankAccountName || ''}`, 76, 244);
    pdf.text(`Bank Name & Branch : ${settings.bankNameBranch || ''}`, 76, 251);
    if(settings.qrData){
      pdf.setFont('helvetica', 'bold'); pdf.text('SCAN & PAY', 188, 237, {align:'center'});
      try{ pdf.addImage(settings.qrData, settings.qrData.includes('jpeg') ? 'JPEG' : 'PNG', 176, 241, 22, 22); }catch(e){}
    }
    pdf.line(5, 266, 205, 266);
    pdf.setFont('helvetica', 'bold'); pdf.text('Terms and Conditions', 8, 272);
    pdf.setFont('helvetica', 'normal'); pdf.text(pdf.splitTextToSize(settings.terms || '', 92), 8, 277);
    pdf.line(100, 266, 100, 287); pdf.line(145, 266, 145, 287);
    pdf.setFont('helvetica', 'bold'); pdf.text(`For ${settings.companyName || 'FreeBill ERP'}`, 173, 272, {align:'center'});
    if(settings.signatureData){
      try{ pdf.addImage(settings.signatureData, settings.signatureData.includes('jpeg') ? 'JPEG' : 'PNG', 157, 274, 32, 9); }catch(e){}
    }
    pdf.text("Receiver's Signature / Seal", 122, 284, {align:'center'});
    pdf.text('Authorised Signature', 174, 284, {align:'center'});
    pdf.setFontSize(8); pdf.text(settings.footerNote || 'Generated by FreeBill ERP', 105, 294, {align:'center'});
    pdf.save(`${docData.number || type}.pdf`);
    toast('PDF downloaded', 'success');
  }

  // ---- Seed demo data on first load ----
  function seed(){
    const adminUser = {
      name:'FreeBill Admin',
      username:'freebill@2003',
      email:'admin@freebill.local',
      password:'181629',
      company:'FreeBill ERP',
      role:'admin',
      status:'active'
    };
    const users = get(KEYS.users, []);
    if(!users.length){
      set(KEYS.users, [adminUser]);
    } else {
      const normalizedUsers = users.map(u => {
        const normalized = {role:'user', status:'active', username:u.email || '', ...u};
        if(normalized.role !== 'admin' && !normalized.expiryDate){
          normalized.trialStartedAt = normalized.trialStartedAt || todayISO();
          normalized.expiryDate = addDaysISO(7);
          normalized.planName = normalized.planName || '1 Week Free Trial';
        }
        return normalized;
      });
      const adminIdx = normalizedUsers.findIndex(u => (u.username || '').toLowerCase() === adminUser.username);
      if(adminIdx >= 0) normalizedUsers[adminIdx] = {...normalizedUsers[adminIdx], ...adminUser};
      else normalizedUsers.unshift(adminUser);
      set(KEYS.users, normalizedUsers);
    }
    if(!get(KEYS.settings)){
      set(KEYS.settings, {
        companyName:'FreeBill Demo Sdn Bhd', tagline:'Simple. Fast. Free.',
        gst:'GST-000111222', address:'12, Jalan Teknologi, 47810 Petaling Jaya, Selangor',
        phone:'+60 12-345 6789', email:'admin@freebill.test', website:'www.freebill.test',
        officeAddress:'12, Jalan Teknologi, 47810 Petaling Jaya, Selangor',
        currency:'RM', taxRate:6, invoiceTitle:'GST INVOICE', stateOfSupply:'',
        bankAccountNo:'', bankIfsc:'', bankAccountName:'', bankNameBranch:'',
        terms:'1. Certified that the particulars given above are true and correct.\n2. Goods once sold will not be taken back or exchanged.\n3. All disputes are subject to local jurisdiction only.',
        footerNote:"Think Before You Print - Let's Go Green Together",
        logoData:'', qrData:'', signatureData:'',
        docPrefixes: {invoice:'INV', quotation:'QUO', purchase:'PO', delivery:'DO'}
      });
    } else {
      const existingSettings = get(KEYS.settings);
      if(!existingSettings.docPrefixes){
        existingSettings.docPrefixes = {invoice:'INV', quotation:'QUO', purchase:'PO', delivery:'DO'};
        set(KEYS.settings, existingSettings);
      }
    }
    if(!get(KEYS.customers)){
      set(KEYS.customers, [
        {id: uid('CUS'), name:'Tan Wei Ming', company:'Maju Jaya Trading', email:'weiming@majujaya.com', phone:'012-3456789', address:'Kuala Lumpur', balance:1250.00},
        {id: uid('CUS'), name:'Nur Aisyah', company:'Aisyah Boutique', email:'aisyah@boutique.my', phone:'013-2223344', address:'Shah Alam', balance:0},
        {id: uid('CUS'), name:'Ravi Kumar', company:'Kumar Enterprises', email:'ravi@kumarent.com', phone:'016-7788990', address:'Johor Bahru', balance:480.50},
        {id: uid('CUS'), name:'Lim Choo Hong', company:'CH Hardware Sdn Bhd', email:'choohong@chhardware.my', phone:'019-6543210', address:'Penang', balance:2100.00},
      ]);
    }
    if(!get(KEYS.suppliers)){
      set(KEYS.suppliers, [
        {id: uid('SUP'), name:'Global Paper Supplies', contact:'Ahmad Faiz', email:'sales@globalpaper.com', phone:'03-77889900', address:'Klang, Selangor'},
        {id: uid('SUP'), name:'TechParts Distribution', contact:'Wong Mei Ling', email:'orders@techparts.my', phone:'03-88112233', address:'Puchong, Selangor'},
        {id: uid('SUP'), name:'Prime Packaging Co', contact:'Siti Zulaikha', email:'info@primepack.my', phone:'04-2223311', address:'Butterworth, Penang'},
      ]);
    }
    if(!get(KEYS.products)){
      set(KEYS.products, [
        {id: uid('PRD'), name:'A4 Copy Paper (Ream)', sku:'STA-0001', category:'Stationery', hsn:'4802', gstRate:6, unit:'NOS', price:12.90, cost:9.50, stock:340, lowStock:50},
        {id: uid('PRD'), name:'Wireless Mouse', sku:'ELE-0002', category:'Electronics', hsn:'8471', gstRate:6, unit:'NOS', price:39.90, cost:24.00, stock:18, lowStock:20},
        {id: uid('PRD'), name:'Thermal Receipt Roll', sku:'STA-0003', category:'Stationery', hsn:'4811', gstRate:6, unit:'ROLL', price:4.50, cost:2.80, stock:5, lowStock:30},
        {id: uid('PRD'), name:'USB-C Cable 1m', sku:'ELE-0004', category:'Electronics', hsn:'8544', gstRate:6, unit:'NOS', price:15.00, cost:8.00, stock:120, lowStock:25},
        {id: uid('PRD'), name:'Office Chair (Standard)', sku:'FUR-0005', category:'Furniture', hsn:'9401', gstRate:6, unit:'NOS', price:249.00, cost:170.00, stock:12, lowStock:5},
        {id: uid('PRD'), name:'Whiteboard Marker (Box)', sku:'STA-0006', category:'Stationery', hsn:'9608', gstRate:6, unit:'BOX', price:18.00, cost:11.00, stock:60, lowStock:15},
      ]);
    }
    if(!get(KEYS.invoices)){
      const cust = get(KEYS.customers, []);
      const mk = (num, custIdx, amt, status, days) => {
        const d = new Date(); d.setDate(d.getDate()-days);
        return {id: uid('INV'), number:num, customer: cust[custIdx]?.name || 'Walk-in', date:d.toISOString().slice(0,10),
          dueDate: d.toISOString().slice(0,10), amount: amt, status, items:[]};
      };
      set(KEYS.invoices, [
        mk('INV-1001',0,1250.00,'paid',20),
        mk('INV-1002',1,860.00,'pending',3),
        mk('INV-1003',2,480.50,'overdue',15),
        mk('INV-1004',3,2100.00,'paid',7),
        mk('INV-1005',0,320.00,'draft',1),
      ]);
    }
    if(!get(KEYS.quotations)) set(KEYS.quotations, []);
    if(!get(KEYS.purchases)) set(KEYS.purchases, []);
    if(!get(KEYS.deliveries)) set(KEYS.deliveries, []);
    if(!get(KEYS.notifications)) set(KEYS.notifications, []);
  }

  function requireAuth(){
    const s = get(KEYS.session);
    if(!s){ window.location.href = (location.pathname.includes('/pages/') ? '../login.html' : 'login.html'); }
    return s;
  }

  // ---- Storage environment self-test ----
  // Registered users/passwords live in the browser's localStorage. That storage
  // IS permanent (it survives closing the tab, restarting the computer, etc.)
  // UNLESS: (a) the site is opened as a local file:// page instead of being
  // served over http/https, (b) the browser is in private/incognito mode with
  // storage blocked, or (c) the user manually clears site data. This check
  // surfaces those situations instead of silently failing.
  function storageHealthCheck(){
    const showBanner = (msg) => {
      if(document.getElementById('fbStorageWarning')) return;
      const banner = document.createElement('div');
      banner.id = 'fbStorageWarning';
      banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#EF4444;color:#fff;text-align:center;padding:10px 16px;font:600 13px/1.4 Inter,system-ui,sans-serif;';
      banner.innerHTML = msg;
      document.body.appendChild(banner);
    };
    if(location.protocol === 'file:'){
      showBanner('⚠️ You opened this app directly as a file. Your saved accounts will NOT be remembered reliably. Please run it from a real web server (e.g. <code style="color:#FEF08A">python3 -m http.server</code>) or upload it to hosting, then open it via http:// or https://.');
      return false;
    }
    try{
      const testKey = '__fb_storage_test__';
      localStorage.setItem(testKey, '1');
      localStorage.removeItem(testKey);
      return true;
    }catch(e){
      showBanner('⚠️ This browser is blocking saved data (private/incognito mode or storage disabled). Please use normal browsing mode so your account can be saved permanently.');
      return false;
    }
  }
  document.addEventListener('DOMContentLoaded', storageHealthCheck);

  function logout(){
    localStorage.removeItem(KEYS.session);
    localStorage.removeItem('fb_token');
    window.location.href = (location.pathname.includes('/pages/') ? '../login.html' : 'login.html');
  }

  return { KEYS, get, set, uid, money, todayISO, addDaysISO, daysUntil, planLabel, toast, seed, requireAuth, requireAdmin, isAdmin, escapeHtml, logout,
    findLiveUser, isExpired, accountLockStatus, contactEmail, docNumber, requireActiveSubscriptionForDocuments, calcItems, notify, downloadDocumentPdf };
})();

document.addEventListener('DOMContentLoaded', FB.seed);
