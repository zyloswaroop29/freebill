/* =========================================================
   FreeBill ERP — report.js
   ========================================================= */

let reportChart, currentReportData = [], currentReportCols = [];

function buildReport(type){
  const invoices = FB.get(FB.KEYS.invoices, []);
  const products = FB.get(FB.KEYS.products, []);
  const customers = FB.get(FB.KEYS.customers, []);
  const suppliers = FB.get(FB.KEYS.suppliers, []);
  const settings = FB.get(FB.KEYS.settings, {});

  let cols = [], rows = [], chartLabels = [], chartData = [], total = 0, title = '';

  if(type === 'sales'){
    title = 'Sales by Invoice';
    cols = ['Invoice #','Customer','Date','Status','Amount'];
    rows = invoices.map(i => [i.number, i.customer, i.date, i.status, i.amount]);
    total = invoices.reduce((s,i)=>s+i.amount,0);
    chartLabels = invoices.map(i=>i.number);
    chartData = invoices.map(i=>i.amount);
  }
  else if(type === 'product'){
    title = 'Product Report';
    cols = ['Product','SKU','Category','Price','Stock','Stock Value'];
    rows = products.map(p => [p.name, p.sku, p.category, p.price, p.stock, +(p.price*p.stock).toFixed(2)]);
    total = products.reduce((s,p)=>s+p.price*p.stock,0);
    chartLabels = products.map(p=>p.name);
    chartData = products.map(p=>p.stock);
  }
  else if(type === 'customer'){
    title = 'Customer Report';
    cols = ['Name','Company','Email','Phone','Balance'];
    rows = customers.map(c => [c.name, c.company, c.email, c.phone, c.balance||0]);
    total = customers.reduce((s,c)=>s+(c.balance||0),0);
    chartLabels = customers.map(c=>c.name);
    chartData = customers.map(c=>c.balance||0);
  }
  else if(type === 'supplier'){
    title = 'Supplier Report';
    cols = ['Name','Contact','Email','Phone','Address'];
    rows = suppliers.map(s => [s.name, s.contact, s.email, s.phone, s.address]);
    total = suppliers.length;
    chartLabels = suppliers.map(s=>s.name);
    chartData = suppliers.map(()=>1);
  }
  else if(type === 'gst'){
    title = 'GST Report';
    const rate = (settings.taxRate ?? 6)/100;
    cols = ['Invoice #','Customer','Amount (incl. tax)','Tax Estimate'];
    rows = invoices.map(i => [i.number, i.customer, i.amount, +(i.amount - i.amount/(1+rate)).toFixed(2)]);
    total = rows.reduce((s,r)=>s+r[3],0);
    chartLabels = invoices.map(i=>i.number);
    chartData = rows.map(r=>r[3]);
  }
  else if(type === 'pl'){
    title = 'Profit & Loss';
    const revenue = invoices.filter(i=>i.status!=='draft').reduce((s,i)=>s+i.amount,0);
    const cost = products.reduce((s,p)=>s+p.cost*Math.max(1,(400-p.stock)),0) * 0 + revenue*0.62; // demo COGS estimate
    const profit = revenue - cost;
    cols = ['Metric','Amount'];
    rows = [['Revenue', +revenue.toFixed(2)], ['Cost of Goods (est.)', +cost.toFixed(2)], ['Net Profit', +profit.toFixed(2)]];
    total = profit;
    chartLabels = ['Revenue','Cost','Profit'];
    chartData = [revenue, cost, profit];
  }
  else if(type === 'outstanding'){
    title = 'Outstanding Payments';
    const out = invoices.filter(i => i.status==='pending' || i.status==='overdue');
    cols = ['Invoice #','Customer','Due Date','Status','Amount'];
    rows = out.map(i => [i.number, i.customer, i.dueDate, i.status, i.amount]);
    total = out.reduce((s,i)=>s+i.amount,0);
    chartLabels = out.map(i=>i.number);
    chartData = out.map(i=>i.amount);
  }
  else if(type === 'inventory'){
    title = 'Inventory Report';
    cols = ['Product','SKU','Stock','Alert Level','Status'];
    rows = products.map(p => [p.name, p.sku, p.stock, p.lowStock, p.stock<=p.lowStock?'Low Stock':'OK']);
    total = products.reduce((s,p)=>s+p.stock,0);
    chartLabels = products.map(p=>p.name);
    chartData = products.map(p=>p.stock);
  }

  return {title, cols, rows, chartLabels, chartData, total};
}

function renderReport(){
  const type = document.getElementById('reportType').value;
  const r = buildReport(type);
  currentReportData = r.rows;
  currentReportCols = r.cols;

  document.getElementById('chartTitle').textContent = r.title;
  document.getElementById('reportTotal').textContent = typeof r.total === 'number' ? FB.money(r.total) : r.total;
  document.getElementById('reportCount').textContent = r.rows.length;

  const head = document.getElementById('reportHead');
  head.innerHTML = r.cols.map(c => `<th>${c}</th>`).join('');
  const body = document.getElementById('reportBody');
  body.innerHTML = r.rows.length ? r.rows.map(row => `<tr>${row.map(v => `<td>${v}</td>`).join('')}</tr>`).join('')
    : `<tr><td colspan="${r.cols.length}" class="empty-state border-0"><i class="fa-solid fa-chart-line d-block"></i>No data available for this report yet.</td></tr>`;

  if(reportChart) reportChart.destroy();
  reportChart = new Chart(document.getElementById('reportChart'), {
    type: 'bar',
    data: { labels: r.chartLabels, datasets: [{ label: r.title, data: r.chartData, backgroundColor: '#2563EB', borderRadius: 6 }] },
    options: { plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:'rgba(148,163,184,.15)'}} } }
  });
}

document.getElementById('reportType').addEventListener('change', renderReport);

document.getElementById('exportBtn').addEventListener('click', () => {
  const ws = XLSX.utils.aoa_to_sheet([currentReportCols, ...currentReportData]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Report');
  XLSX.writeFile(wb, `FreeBill_${document.getElementById('reportType').value}_report.xlsx`);
  FB.toast('Excel file exported', 'success');
});

document.addEventListener('DOMContentLoaded', () => {
  // Support deep links from Dashboard, e.g. reports.html?type=sales
  const type = new URLSearchParams(window.location.search).get('type');
  const select = document.getElementById('reportType');
  if(type && select && [...select.options].some(o => o.value === type)) select.value = type;
  renderReport();
});
