/* =========================================================
   FreeBill ERP - documents.js
   ========================================================= */

let documentsTable;

function badgeClass(status){
  const map = {
    paid:'badge-paid', accepted:'badge-paid', received:'badge-paid', delivered:'badge-paid',
    pending:'badge-pending', sent:'badge-pending', ordered:'badge-pending',
    overdue:'badge-overdue', rejected:'badge-overdue', cancelled:'badge-overdue',
    draft:'badge-draft', shipped:'badge-draft'
  };
  return map[status] || 'badge-draft';
}

function collectDocuments(){
  const rows = [];
  FB.get(FB.KEYS.invoices, []).forEach(d => rows.push({
    id:d.id, docType:'invoice', number:d.number, type:'Sales Invoice', party:d.customer, date:d.date, amount:d.amount, status:d.status, href:'invoice.html'
  }));
  FB.get(FB.KEYS.quotations, []).forEach(d => rows.push({
    id:d.id, docType:'quotation', number:d.number, type:'Quotation', party:d.customer, date:d.date, amount:d.amount, status:d.status, href:'quotation.html'
  }));
  FB.get(FB.KEYS.purchases, []).forEach(d => rows.push({
    id:d.id, docType:'purchase', number:d.number, type:'Purchase Order', party:d.supplier, date:d.date, amount:d.amount, status:d.status, href:'purchase.html'
  }));
  FB.get(FB.KEYS.deliveries, []).forEach(d => rows.push({
    id:d.id, docType:'delivery', number:d.number, type:'Delivery Order', party:d.customer, date:d.date, amount:d.amount ?? null, status:d.status, href:'delivery.html'
  }));
  return rows.sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
}

function setText(id, value){
  const el = document.getElementById(id);
  if(el) el.textContent = value;
}

function renderDocuments(){
  const invoices = FB.get(FB.KEYS.invoices, []);
  const quotations = FB.get(FB.KEYS.quotations, []);
  const purchases = FB.get(FB.KEYS.purchases, []);
  const deliveries = FB.get(FB.KEYS.deliveries, []);
  setText('docInvoiceCount', invoices.length);
  setText('docQuoteCount', quotations.length);
  setText('docPurchaseCount', purchases.length);
  setText('docDeliveryCount', deliveries.length);

  const tbody = document.querySelector('#documentsTable tbody');
  const filter = document.getElementById('docTypeFilter')?.value || 'all';
  const docs = collectDocuments().filter(doc => filter === 'all' || doc.docType === filter);
  if(documentsTable){ documentsTable.destroy(); documentsTable = null; }
  tbody.innerHTML = '';
  if(!docs.length){
    tbody.innerHTML = `<tr><td colspan="7" class="empty-state border-0"><i class="fa-solid fa-folder-open d-block"></i>No saved documents yet.</td></tr>`;
    return;
  }
  docs.forEach(doc => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${FB.escapeHtml(doc.number || '-')}</td>
        <td>${FB.escapeHtml(doc.type)}</td>
        <td>${FB.escapeHtml(doc.party || '-')}</td>
        <td>${FB.escapeHtml(doc.date || '-')}</td>
        <td>${doc.amount === null ? '-' : FB.money(doc.amount)}</td>
        <td><span class="badge-status ${badgeClass(doc.status)}">${FB.escapeHtml(doc.status || '-')}</span></td>
        <td class="row-actions">
          <a class="icon-btn" href="${doc.href}" title="Open"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
          <button class="icon-btn" onclick="FB.downloadDocumentPdf('${doc.docType}', '${doc.id}')" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></button>
        </td>
      </tr>`);
  });
  documentsTable = $('#documentsTable').DataTable({ pageLength: 10, lengthChange:false, order:[[3,'desc']], language:{search:'', searchPlaceholder:'Search all documents...'} });
}

document.getElementById('docTypeFilter')?.addEventListener('change', renderDocuments);
document.addEventListener('DOMContentLoaded', renderDocuments);
