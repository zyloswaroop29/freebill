/* =========================================================
   FreeBill ERP - login.js  (handles login.html & register.html)
   Backed by the Node backend (backend/server.js). Plain email +
   password auth — no OTP / email verification step.
   ========================================================= */

function showLoginNotice(message, type='danger', withContact=false){
  const notice = document.getElementById('loginNotice');
  if(!notice) return;
  notice.className = `alert alert-${type}`;
  notice.innerHTML = `${message}${withContact ? ` <a class="alert-link" href="mailto:${FB.contactEmail()}">Contact Us</a>` : ''}`;
}

function wirePasswordToggles(){
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-toggle-password]');
    if(!btn) return;
    const input = document.querySelector(btn.dataset.togglePassword);
    if(!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-solid fa-eye"></i>' : '<i class="fa-solid fa-eye-slash"></i>';
  });
}

function startSession(token, user){
  localStorage.setItem('fb_token', token);
  FB.set(FB.KEYS.session, {
    name: user.name,
    username: user.username,
    email: user.email,
    company: user.company,
    role: user.role || 'user'
  });
}

function goToDashboard(user){
  let dest = user.role === 'admin' ? 'pages/admin.html' : 'dashboard.html';
  if(user.role !== 'admin' && FB.isExpired(user)) dest = 'pages/subscription.html';
  setTimeout(() => window.location.href = dest, 400);
}

/* ---------------- Registration ---------------- */

document.getElementById('registerForm')?.addEventListener('submit', async function(e){
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const company = document.getElementById('regCompany').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const password = document.getElementById('regPassword').value;
  const password2 = document.getElementById('regPassword2').value;
  const agree = document.getElementById('agreeTerms').checked;

  if(password !== password2){ FB.toast('Passwords do not match', 'danger'); return; }
  if(password.length < 6){ FB.toast('Password must be at least 6 characters', 'warning'); return; }
  if(!agree){ FB.toast('Please agree to the Terms of Service', 'warning'); return; }

  try{
    const result = await fbApi('/auth/register', { method:'POST', body:{ name, company, email, password } });
    startSession(result.token, result.user);
    FB.toast('Account created. Your 7-day free trial has started.', 'success');
    goToDashboard(result.user);
  }catch(err){
    FB.toast(err.data?.error || err.message, 'danger');
  }
});

/* ---------------- Login (plain email + password) ---------------- */

document.getElementById('loginForm')?.addEventListener('submit', async function(e){
  e.preventDefault();
  const loginId = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value;

  try{
    const result = await fbApi('/auth/login', { method:'POST', body:{ email: loginId, password } });
    startSession(result.token, result.user);
    FB.toast('Welcome back, ' + result.user.name.split(' ')[0] + '!', 'success');
    goToDashboard(result.user);
  }catch(err){
    showLoginNotice(err.data?.error || err.message, 'danger', err.status === 403);
    FB.toast(err.data?.error || err.message, 'danger');
  }
});

/* ---------------- Forgot password (email + new password, no OTP) ---------------- */

document.getElementById('forgotPasswordLink')?.addEventListener('click', (e) => {
  e.preventDefault();
  let modalEl = document.getElementById('otpFlowModal');
  if(!modalEl){
    document.body.insertAdjacentHTML('beforeend', `
      <div class="modal fade" id="otpFlowModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content glass-card border-0">
            <div class="modal-header border-0">
              <h5 class="modal-title">Reset Password</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p class="text-muted-c small">Enter your account email and a new password.</p>
              <form id="resetPasswordForm">
                <div class="mb-3">
                  <label class="form-label">Email address</label>
                  <input type="email" class="form-control" id="resetEmail" required>
                </div>
                <div class="mb-3">
                  <label class="form-label">New Password</label>
                  <div class="password-field">
                    <input type="password" class="form-control" id="resetNewPassword" required>
                    <button type="button" class="password-toggle" data-toggle-password="#resetNewPassword" aria-label="Show password"><i class="fa-solid fa-eye"></i></button>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary-grad w-100">Reset Password</button>
              </form>
            </div>
          </div>
        </div>
      </div>`);
    modalEl = document.getElementById('otpFlowModal');
  }
  new bootstrap.Modal(modalEl).show();

  document.getElementById('resetPasswordForm').onsubmit = async (event) => {
    event.preventDefault();
    const email = document.getElementById('resetEmail').value.trim().toLowerCase();
    const newPassword = document.getElementById('resetNewPassword').value;
    if(newPassword.length < 6){ FB.toast('Password must be at least 6 characters', 'warning'); return; }
    try{
      await fbApi('/auth/reset-password', { method:'POST', body:{ email, newPassword } });
      bootstrap.Modal.getInstance(modalEl)?.hide();
      document.getElementById('loginPassword').value = '';
      FB.toast('Password reset. Please login with the new password.', 'success');
    }catch(err){
      FB.toast(err.data?.error || err.message, 'danger');
    }
  };
});

wirePasswordToggles();
