/* =========================================================
   FreeBill ERP — delivery.js
   ========================================================= */

let doTable;
const doBadge = {pending:'badge-pending', shipped:'badge-draft', delivered:'badge-paid'};

function loadDOs(){
  const data = FB.get(FB.KEYS.deliveries, []);
  const tbody = document.querySelector('#doTable tbody');
  if(doTable){ doTable.destroy(); doTable = null; }
  tbody.innerHTML = '';
  if(data.length === 0){
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state border-0"><i class="fa-solid fa-truck d-block"></i>No delivery orders yet.</td></tr>`;
    return;
  }
  data.forEach(d => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${d.number}</td>
        <td>${d.customer}</td>
        <td>${d.date}</td>
        <td>${d.invoice||'-'}</td>
        <td><span class="badge-status ${doBadge[d.status]}">${d.status}</span></td>
        <td class="row-actions">
          <button class="icon-btn" onclick="FB.downloadDocumentPdf('delivery','${d.id}')" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></button>
          <button class="icon-btn" onclick="editDO('${d.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deleteDO('${d.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  doTable = $('#doTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search deliveries...'} });
}

function addDOItemRow(item={}){
  const clone = document.getElementById('doItemRowTpl').content.cloneNode(true);
  const row = clone.querySelector('.doc-item-row');
  row.querySelector('.item-name').value = item.name || '';
  row.querySelector('.item-detail').value = item.description || '';
  row.querySelector('.item-hsn').value = item.hsn || '';
  row.querySelector('.item-gst').value = item.gstRate ?? 0;
  row.querySelector('.item-unit').value = item.unit || 'NOS';
  row.querySelector('.item-qty').value = item.qty ?? 1;
  row.querySelector('.item-price').value = item.price ?? '';
  row.querySelectorAll('input').forEach(input => input.addEventListener('input', recalcDOTotals));
  document.getElementById('doItemsWrap').appendChild(row);
  recalcDOTotals();
}

function collectDOItems(){
  return [...document.querySelectorAll('#doItemsWrap .doc-item-row')].map(row => ({
    name: row.querySelector('.item-name').value.trim(),
    description: row.querySelector('.item-detail').value.trim(),
    hsn: row.querySelector('.item-hsn').value.trim(),
    gstRate: parseFloat(row.querySelector('.item-gst').value) || 0,
    unit: row.querySelector('.item-unit').value.trim() || 'NOS',
    qty: parseFloat(row.querySelector('.item-qty').value) || 0,
    price: parseFloat(row.querySelector('.item-price').value) || 0
  })).filter(it => it.name || it.qty || it.price);
}

function recalcDOTotals(){
  const totals = FB.calcItems(collectDOItems());
  document.getElementById('doSubtotal').textContent = FB.money(totals.subtotal);
  document.getElementById('doTax').textContent = FB.money(totals.tax);
  document.getElementById('doTotal').textContent = FB.money(totals.total);
}

function populateDOCustomers(){
  const sel = document.getElementById('doCustomer');
  const customers = FB.get(FB.KEYS.customers, []);
  sel.innerHTML = customers.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
}

function openDOModal(){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  document.getElementById('doForm').reset();
  document.getElementById('doId').value = '';
  populateDOCustomers();
  const dos = FB.get(FB.KEYS.deliveries, []);
  document.getElementById('doNumber').value = FB.docNumber('delivery', dos);
  document.getElementById('doDate').value = FB.todayISO();
  document.getElementById('doItemsWrap').innerHTML = '';
  addDOItemRow();
  new bootstrap.Modal(document.getElementById('doModal')).show();
}

function editDO(id){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const data = FB.get(FB.KEYS.deliveries, []);
  const d = data.find(x => x.id === id);
  if(!d) return;
  populateDOCustomers();
  document.getElementById('doId').value = d.id;
  document.getElementById('doNumber').value = d.number;
  document.getElementById('doCustomer').value = d.customer;
  document.getElementById('doDate').value = d.date;
  document.getElementById('doStatus').value = d.status;
  document.getElementById('doInvoice').value = d.invoice||'';
  document.getElementById('doItemsWrap').innerHTML = '';
  (d.items && d.items.length ? d.items : [{name:'Goods', qty:1, price:d.amount || 0, gstRate:0, unit:'NOS'}]).forEach(addDOItemRow);
  recalcDOTotals();
  new bootstrap.Modal(document.getElementById('doModal')).show();
}

function deleteDO(id){
  if(!confirm('Delete this delivery order?')) return;
  let data = FB.get(FB.KEYS.deliveries, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.deliveries, data);
  loadDOs();
  FB.toast('Delivery order deleted', 'info');
}

document.getElementById('doForm').addEventListener('submit', function(e){
  e.preventDefault();
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const id = document.getElementById('doId').value;
  const data = FB.get(FB.KEYS.deliveries, []);
  const items = collectDOItems();
  const totals = FB.calcItems(items);
  const payload = {
    number: document.getElementById('doNumber').value,
    customer: document.getElementById('doCustomer').value,
    date: document.getElementById('doDate').value,
    status: document.getElementById('doStatus').value,
    invoice: document.getElementById('doInvoice').value.trim(),
    amount: totals.total,
    subtotal: totals.subtotal,
    tax: totals.tax,
    items,
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Delivery order updated', 'success');
  } else {
    data.push({id: FB.uid('DO'), ...payload});
    FB.toast('Delivery order created', 'success');
  }
  FB.set(FB.KEYS.deliveries, data);
  bootstrap.Modal.getInstance(document.getElementById('doModal')).hide();
  loadDOs();
});

document.addEventListener('DOMContentLoaded', loadDOs);
