/* =========================================================
   FreeBill ERP — profile.js
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  const session = FB.get(FB.KEYS.session, {});
  const liveUser = FB.findLiveUser(session) || session;
  document.getElementById('profileAvatar').src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(session.name||'U')}`;
  document.getElementById('profileName').textContent = session.name || '-';
  document.getElementById('profileCompany').textContent = session.company || '-';
  document.getElementById('profileEmail').textContent = session.email || '-';
  document.getElementById('profilePlan').textContent = FB.planLabel(liveUser);
  document.getElementById('profileDaysLeft').textContent = `${FB.daysUntil(liveUser.expiryDate)} day(s)`;
  document.getElementById('profFormName').value = session.name || '';
  document.getElementById('profFormCompany').value = session.company || '';
  document.getElementById('profFormEmail').value = session.email || '';
});

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-toggle-password]');
  if(!btn) return;
  const input = document.querySelector(btn.dataset.togglePassword);
  if(!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  btn.innerHTML = input.type === 'password' ? '<i class="fa-solid fa-eye"></i>' : '<i class="fa-solid fa-eye-slash"></i>';
});

document.getElementById('profileForm').addEventListener('submit', function(e){
  e.preventDefault();
  const session = FB.get(FB.KEYS.session, {});
  session.name = document.getElementById('profFormName').value.trim();
  session.company = document.getElementById('profFormCompany').value.trim();
  FB.set(FB.KEYS.session, session);

  const users = FB.get(FB.KEYS.users, []);
  const idx = users.findIndex(u => u.email === session.email);
  if(idx > -1){ users[idx].name = session.name; users[idx].company = session.company; FB.set(FB.KEYS.users, users); }

  FB.toast('Profile updated', 'success');
  setTimeout(() => window.location.reload(), 600);
});

document.getElementById('changePasswordForm').addEventListener('submit', function(e){
  e.preventDefault();
  const session = FB.get(FB.KEYS.session, {});
  const users = FB.get(FB.KEYS.users, []);
  const idx = users.findIndex(u => (u.email || '').toLowerCase() === (session.email || '').toLowerCase());
  const current = document.getElementById('currentPassword').value;
  const next = document.getElementById('newPassword').value;
  const confirmNext = document.getElementById('confirmNewPassword').value;

  if(idx < 0){ FB.toast('Account not found', 'danger'); return; }
  if(users[idx].password !== current){ FB.toast('Current password is incorrect', 'danger'); return; }
  if(next.length < 6){ FB.toast('New password must be at least 6 characters', 'warning'); return; }
  if(next !== confirmNext){ FB.toast('New passwords do not match', 'danger'); return; }

  users[idx].password = next;
  FB.set(FB.KEYS.users, users);
  this.reset();
  FB.toast('Password changed successfully', 'success');
});
