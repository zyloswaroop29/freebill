/* =========================================================
   FreeBill ERP — supplier.js
   ========================================================= */

let supplierTable;

function loadSuppliers(){
  const data = FB.get(FB.KEYS.suppliers, []);
  const tbody = document.querySelector('#supplierTable tbody');
  tbody.innerHTML = '';
  data.forEach(s => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${s.name}</td>
        <td>${s.contact||'-'}</td>
        <td>${s.email||'-'}</td>
        <td>${s.phone||'-'}</td>
        <td>${s.address||'-'}</td>
        <td class="row-actions">
          <button class="icon-btn" onclick="editSupplier('${s.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deleteSupplier('${s.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  if(supplierTable) supplierTable.destroy();
  supplierTable = $('#supplierTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search suppliers...'} });
}

function openSupplierModal(){
  document.getElementById('supplierForm').reset();
  document.getElementById('supId').value = '';
  document.getElementById('supplierModalTitle').textContent = 'Add Supplier';
}

function editSupplier(id){
  const data = FB.get(FB.KEYS.suppliers, []);
  const s = data.find(x => x.id === id);
  if(!s) return;
  document.getElementById('supplierModalTitle').textContent = 'Edit Supplier';
  document.getElementById('supId').value = s.id;
  document.getElementById('supName').value = s.name;
  document.getElementById('supContact').value = s.contact||'';
  document.getElementById('supEmail').value = s.email||'';
  document.getElementById('supPhone').value = s.phone||'';
  document.getElementById('supAddress').value = s.address||'';
  new bootstrap.Modal(document.getElementById('supplierModal')).show();
}

function deleteSupplier(id){
  if(!confirm('Delete this supplier?')) return;
  let data = FB.get(FB.KEYS.suppliers, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.suppliers, data);
  loadSuppliers();
  FB.toast('Supplier deleted', 'info');
}

document.getElementById('supplierForm').addEventListener('submit', function(e){
  e.preventDefault();
  const id = document.getElementById('supId').value;
  const data = FB.get(FB.KEYS.suppliers, []);
  const payload = {
    name: document.getElementById('supName').value.trim(),
    contact: document.getElementById('supContact').value.trim(),
    email: document.getElementById('supEmail').value.trim(),
    phone: document.getElementById('supPhone').value.trim(),
    address: document.getElementById('supAddress').value.trim(),
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Supplier updated', 'success');
  } else {
    data.push({id: FB.uid('SUP'), ...payload});
    FB.toast('Supplier added', 'success');
  }
  FB.set(FB.KEYS.suppliers, data);
  bootstrap.Modal.getInstance(document.getElementById('supplierModal')).hide();
  loadSuppliers();
});

document.addEventListener('DOMContentLoaded', loadSuppliers);
