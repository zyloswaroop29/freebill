/* =========================================================
   FreeBill ERP — inventory.js
   ========================================================= */

let invTable;

function loadInventory(){
  const products = FB.get(FB.KEYS.products, []);
  const tbody = document.querySelector('#inventoryTable tbody');
  tbody.innerHTML = '';

  let totalUnits = 0, stockValue = 0, lowCount = 0;
  products.forEach(p => {
    totalUnits += p.stock;
    stockValue += p.stock * (p.cost || p.price * 0.7);
    if(p.stock <= p.lowStock) lowCount++;
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${p.name}</td>
        <td>${p.sku}</td>
        <td>${p.category||'-'}</td>
        <td><span id="stockQty-${p.id}">${p.stock}</span></td>
        <td>${p.lowStock}</td>
        <td>${stockBadgeLocal(p)}</td>
        <td class="row-actions">
          <button class="icon-btn" onclick="adjustStock('${p.id}', -1)" title="Decrease"><i class="fa-solid fa-minus"></i></button>
          <button class="icon-btn" onclick="adjustStock('${p.id}', 1)" title="Increase"><i class="fa-solid fa-plus"></i></button>
        </td>
      </tr>`);
  });

  document.getElementById('invTotalSku').textContent = products.length;
  document.getElementById('invTotalUnits').textContent = totalUnits;
  document.getElementById('invStockValue').textContent = FB.money(stockValue);
  document.getElementById('invLowCount').textContent = lowCount;

  if(invTable) invTable.destroy();
  invTable = $('#inventoryTable').DataTable({ pageLength: 10, lengthChange:false, language:{search:'', searchPlaceholder:'Search products...'} });
}

function stockBadgeLocal(p){
  if(p.stock <= 0) return `<span class="badge-status badge-overdue">Out of Stock</span>`;
  if(p.stock <= p.lowStock) return `<span class="badge-status badge-pending">Low Stock</span>`;
  return `<span class="badge-status badge-paid">In Stock</span>`;
}

function adjustStock(id, delta){
  const data = FB.get(FB.KEYS.products, []);
  const idx = data.findIndex(x => x.id === id);
  if(idx === -1) return;
  data[idx].stock = Math.max(0, data[idx].stock + delta);
  FB.set(FB.KEYS.products, data);
  loadInventory();
}

document.addEventListener('DOMContentLoaded', loadInventory);
