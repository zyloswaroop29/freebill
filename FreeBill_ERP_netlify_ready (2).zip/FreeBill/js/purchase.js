/* =========================================================
   FreeBill ERP — purchase.js
   ========================================================= */

let poTable;
const poBadge = {draft:'badge-draft', ordered:'badge-pending', received:'badge-paid', cancelled:'badge-overdue'};

function loadPOs(){
  const data = FB.get(FB.KEYS.purchases, []);
  const tbody = document.querySelector('#poTable tbody');
  if(poTable){ poTable.destroy(); poTable = null; }
  tbody.innerHTML = '';
  if(data.length === 0){
    tbody.innerHTML = `<tr><td colspan="7" class="empty-state border-0"><i class="fa-solid fa-cart-shopping d-block"></i>No purchase orders yet.</td></tr>`;
    return;
  }
  data.forEach(p => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${p.number}</td>
        <td>${p.supplier}</td>
        <td>${p.date}</td>
        <td>${p.expected}</td>
        <td>${FB.money(p.amount)}</td>
        <td><span class="badge-status ${poBadge[p.status]}">${p.status}</span></td>
        <td class="row-actions">
          <button class="icon-btn" onclick="FB.downloadDocumentPdf('purchase','${p.id}')" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></button>
          <button class="icon-btn" onclick="editPO('${p.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="deletePO('${p.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  poTable = $('#poTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search orders...'} });
}

function addPOItemRow(item={}){
  const clone = document.getElementById('poItemRowTpl').content.cloneNode(true);
  const row = clone.querySelector('.doc-item-row');
  row.querySelector('.item-name').value = item.name || '';
  row.querySelector('.item-detail').value = item.description || '';
  row.querySelector('.item-hsn').value = item.hsn || '';
  row.querySelector('.item-gst').value = item.gstRate ?? (FB.get(FB.KEYS.settings, {}).taxRate ?? 0);
  row.querySelector('.item-unit').value = item.unit || 'NOS';
  row.querySelector('.item-qty').value = item.qty ?? 1;
  row.querySelector('.item-price').value = item.price ?? '';
  row.querySelectorAll('input').forEach(input => input.addEventListener('input', recalcPOTotals));
  document.getElementById('poItemsWrap').appendChild(row);
  recalcPOTotals();
}

function collectPOItems(){
  return [...document.querySelectorAll('#poItemsWrap .doc-item-row')].map(row => ({
    name: row.querySelector('.item-name').value.trim(),
    description: row.querySelector('.item-detail').value.trim(),
    hsn: row.querySelector('.item-hsn').value.trim(),
    gstRate: parseFloat(row.querySelector('.item-gst').value) || 0,
    unit: row.querySelector('.item-unit').value.trim() || 'NOS',
    qty: parseFloat(row.querySelector('.item-qty').value) || 0,
    price: parseFloat(row.querySelector('.item-price').value) || 0
  })).filter(it => it.name || it.qty || it.price);
}

function recalcPOTotals(){
  const totals = FB.calcItems(collectPOItems());
  document.getElementById('poSubtotal').textContent = FB.money(totals.subtotal);
  document.getElementById('poTax').textContent = FB.money(totals.tax);
  document.getElementById('poTotal').textContent = FB.money(totals.total);
  document.getElementById('poAmount').value = totals.total.toFixed(2);
}

function populatePOSuppliers(){
  const sel = document.getElementById('poSupplier');
  const suppliers = FB.get(FB.KEYS.suppliers, []);
  sel.innerHTML = suppliers.map(s => `<option value="${s.name}">${s.name}</option>`).join('');
}

function openPOModal(){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  document.getElementById('poForm').reset();
  document.getElementById('poId').value = '';
  populatePOSuppliers();
  const pos = FB.get(FB.KEYS.purchases, []);
  document.getElementById('poNumber').value = FB.docNumber('purchase', pos);
  document.getElementById('poDate').value = FB.todayISO();
  const d = new Date(); d.setDate(d.getDate()+7);
  document.getElementById('poExpected').value = d.toISOString().slice(0,10);
  document.getElementById('poItemsWrap').innerHTML = '';
  addPOItemRow();
  new bootstrap.Modal(document.getElementById('poModal')).show();
}

function editPO(id){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const data = FB.get(FB.KEYS.purchases, []);
  const p = data.find(x => x.id === id);
  if(!p) return;
  populatePOSuppliers();
  document.getElementById('poId').value = p.id;
  document.getElementById('poNumber').value = p.number;
  document.getElementById('poSupplier').value = p.supplier;
  document.getElementById('poDate').value = p.date;
  document.getElementById('poExpected').value = p.expected;
  document.getElementById('poAmount').value = p.amount;
  document.getElementById('poStatus').value = p.status;
  document.getElementById('poItemsWrap').innerHTML = '';
  (p.items && p.items.length ? p.items : [{name:'Goods / Service', qty:1, price:p.amount || 0, gstRate:0, unit:'NOS'}]).forEach(addPOItemRow);
  recalcPOTotals();
  new bootstrap.Modal(document.getElementById('poModal')).show();
}

function deletePO(id){
  if(!confirm('Delete this purchase order?')) return;
  let data = FB.get(FB.KEYS.purchases, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.purchases, data);
  loadPOs();
  FB.toast('Purchase order deleted', 'info');
}

document.getElementById('poForm').addEventListener('submit', function(e){
  e.preventDefault();
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const id = document.getElementById('poId').value;
  const data = FB.get(FB.KEYS.purchases, []);
  const items = collectPOItems();
  const totals = FB.calcItems(items);
  const payload = {
    number: document.getElementById('poNumber').value,
    supplier: document.getElementById('poSupplier').value,
    date: document.getElementById('poDate').value,
    expected: document.getElementById('poExpected').value,
    amount: totals.total,
    subtotal: totals.subtotal,
    tax: totals.tax,
    status: document.getElementById('poStatus').value,
    items,
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Purchase order updated', 'success');
  } else {
    data.push({id: FB.uid('PO'), ...payload});
    FB.toast('Purchase order created', 'success');
  }
  FB.set(FB.KEYS.purchases, data);
  bootstrap.Modal.getInstance(document.getElementById('poModal')).hide();
  loadPOs();
});

document.addEventListener('DOMContentLoaded', loadPOs);
