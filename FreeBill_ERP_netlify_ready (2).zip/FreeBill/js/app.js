/* =========================================================
   FreeBill ERP — app.js
   Reserved for future global app-wide behaviors (Phase 2+).
   Core shared logic currently lives in utils.js and layout.js.
   ========================================================= */
