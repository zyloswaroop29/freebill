/* =========================================================
   FreeBill ERP — dashboard.js
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  const invoices = FB.get(FB.KEYS.invoices, []);
  const customers = FB.get(FB.KEYS.customers, []);
  const products = FB.get(FB.KEYS.products, []);

  // ---- Stat cards ----
  const totalSales = invoices.reduce((s,i)=> s + (i.status!=='draft' ? i.amount : 0), 0);
  const profit = totalSales * 0.32; // demo margin
  const lowStock = products.filter(p => p.stock <= p.lowStock).length;

  document.getElementById('statSales').textContent = FB.money(totalSales);
  document.getElementById('statProfit').textContent = FB.money(profit);
  document.getElementById('statOrders').textContent = invoices.length;
  document.getElementById('statLowStock').textContent = lowStock;

  // ---- Sales chart ----
  const days = Array.from({length: 14}, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (13 - i));
    return d.toLocaleDateString('en-GB', {day:'2-digit', month:'short'});
  });
  const salesData = days.map(() => Math.round(400 + Math.random() * 1600));

  new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
      labels: days,
      datasets: [{
        label: 'Sales',
        data: salesData,
        borderColor: '#2563EB',
        backgroundColor: (ctx) => {
          const g = ctx.chart.ctx.createLinearGradient(0,0,0,220);
          g.addColorStop(0, 'rgba(37,99,235,.35)');
          g.addColorStop(1, 'rgba(37,99,235,0)');
          return g;
        },
        fill: true, tension: .4, pointRadius: 0, borderWidth: 2.5
      }]
    },
    options: {
      plugins:{ legend:{display:false} },
      scales:{
        x:{ grid:{display:false} },
        y:{ grid:{color:'rgba(148,163,184,.15)'}, ticks:{ callback: v => 'RM'+v } }
      }
    }
  });

  // ---- Stock by category ----
  const catTotals = {};
  products.forEach(p => { catTotals[p.category] = (catTotals[p.category]||0) + p.stock; });
  new Chart(document.getElementById('stockChart'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(catTotals),
      datasets: [{ data: Object.values(catTotals), backgroundColor: ['#2563EB','#10B981','#F59E0B','#EF4444','#8B5CF6','#0EA5E9'] }]
    },
    options: { plugins:{ legend:{ position:'bottom', labels:{ boxWidth:10, font:{size:11} } } }, cutout:'65%' }
  });

  // ---- Recent sales table ----
  const badgeClass = {paid:'badge-paid', pending:'badge-pending', overdue:'badge-overdue', draft:'badge-draft'};
  const tbody = document.querySelector('#recentSalesTable tbody');
  invoices.slice(-6).reverse().forEach(inv => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr data-invoice-id="${inv.id}" title="Open invoice ${inv.number}">
        <td class="fw-semibold">${inv.number}</td>
        <td>${inv.customer}</td>
        <td>${inv.date}</td>
        <td>${FB.money(inv.amount)}</td>
        <td><span class="badge-status ${badgeClass[inv.status]}">${inv.status}</span></td>
      </tr>`);
  });
  tbody.querySelectorAll('tr[data-invoice-id]').forEach(row => {
    row.addEventListener('click', () => {
      window.location.href = `pages/invoice.html?open=${encodeURIComponent(row.dataset.invoiceId)}`;
    });
  });

  // ---- Top products (by price desc, demo) ----
  const topList = document.getElementById('topProductsList');
  [...products].sort((a,b) => (b.price*  (400-b.stock)) - (a.price * (400-a.stock))).slice(0,5).forEach(p => {
    topList.insertAdjacentHTML('beforeend', `
      <div class="top-product-row" data-product-id="${p.id}" title="Open ${FB.escapeHtml(p.name)}">
        <div class="prod-icon"><i class="fa-solid fa-box"></i></div>
        <div class="flex-grow-1">
          <div class="fw-semibold small">${p.name}</div>
          <div class="text-muted-c" style="font-size:.75rem">${p.sku} • Stock: ${p.stock}</div>
        </div>
        <div class="fw-semibold small">${FB.money(p.price)}</div>
      </div>`);
  });
  topList.querySelectorAll('[data-product-id]').forEach(row => {
    row.addEventListener('click', () => {
      window.location.href = `pages/products.html?open=${encodeURIComponent(row.dataset.productId)}`;
    });
  });

  // ---- Recent customers ----
  const custList = document.getElementById('recentCustomersList');
  customers.slice(0,4).forEach(c => {
    const initials = c.name.split(' ').map(w=>w[0]).slice(0,2).join('');
    custList.insertAdjacentHTML('beforeend', `
      <div class="col-md-6">
        <div class="mini-customer-card" data-customer-id="${c.id}" title="Open ${FB.escapeHtml(c.name)}">
          <div class="avatar">${initials}</div>
          <div class="flex-grow-1 overflow-hidden">
            <div class="fw-semibold small text-truncate">${c.name}</div>
            <div class="text-muted-c text-truncate" style="font-size:.75rem">${c.company}</div>
          </div>
        </div>
      </div>`);
  });
  custList.querySelectorAll('[data-customer-id]').forEach(row => {
    row.addEventListener('click', () => {
      window.location.href = `pages/customers.html?open=${encodeURIComponent(row.dataset.customerId)}`;
    });
  });

  // ---- Notifications ----
  const notifs = [
    {icon:'fa-triangle-exclamation', color:'#F59E0B', text: `${lowStock} product(s) running low on stock`, href:'pages/inventory.html'},
    {icon:'fa-file-invoice-dollar', color:'#EF4444', text: `${invoices.filter(i=>i.status==='overdue').length} invoice(s) overdue`, href:'pages/invoice.html'},
    {icon:'fa-user-plus', color:'#10B981', text: `${customers.length} customers total`, href:'pages/customers.html'},
  ];
  document.getElementById('notifCount').textContent = notifs.length;
  const notifList = document.getElementById('notifList');
  notifs.forEach(n => {
    notifList.insertAdjacentHTML('beforeend', `
      <div class="notif-item" data-href="${n.href}" title="View details">
        <div class="n-icon" style="background:${n.color}"><i class="fa-solid ${n.icon}"></i></div>
        <div class="small">${n.text}</div>
      </div>`);
  });
  notifList.querySelectorAll('[data-href]').forEach(row => {
    row.addEventListener('click', () => { window.location.href = row.dataset.href; });
  });
});
