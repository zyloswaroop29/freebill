/* =========================================================
   FreeBill ERP — quotation.js
   ========================================================= */

let quoteTable;
const quoteBadge = {draft:'badge-draft', sent:'badge-pending', accepted:'badge-paid', rejected:'badge-overdue'};

function loadQuotes(){
  const data = FB.get(FB.KEYS.quotations, []);
  const tbody = document.querySelector('#quoteTable tbody');
  if(quoteTable){ quoteTable.destroy(); quoteTable = null; }
  tbody.innerHTML = '';
  if(data.length === 0){
    tbody.innerHTML = `<tr><td colspan="7" class="empty-state border-0"><i class="fa-solid fa-file-lines d-block"></i>No quotations yet. Create your first one.</td></tr>`;
    return;
  }
  data.forEach(q => {
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td class="fw-semibold">${q.number}</td>
        <td>${q.customer}</td>
        <td>${q.date}</td>
        <td>${q.validUntil}</td>
        <td>${FB.money(q.amount)}</td>
        <td><span class="badge-status ${quoteBadge[q.status]}">${q.status}</span></td>
        <td class="row-actions">
          <button class="icon-btn" onclick="FB.downloadDocumentPdf('quotation','${q.id}')" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></button>
          <button class="icon-btn" onclick="editQuote('${q.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn" onclick="convertQuoteToInvoice('${q.id}')" title="Convert to Invoice"><i class="fa-solid fa-file-invoice-dollar"></i></button>
          <button class="icon-btn" onclick="deleteQuote('${q.id}')" title="Delete"><i class="fa-solid fa-trash text-danger"></i></button>
        </td>
      </tr>`);
  });
  quoteTable = $('#quoteTable').DataTable({ pageLength: 8, lengthChange:false, language:{search:'', searchPlaceholder:'Search quotations...'} });
}

function addQuoteItemRow(item={}){
  const clone = document.getElementById('quoteItemRowTpl').content.cloneNode(true);
  const row = clone.querySelector('.doc-item-row');
  row.querySelector('.item-name').value = item.name || '';
  row.querySelector('.item-detail').value = item.description || '';
  row.querySelector('.item-hsn').value = item.hsn || '';
  row.querySelector('.item-gst').value = item.gstRate ?? (FB.get(FB.KEYS.settings, {}).taxRate ?? 0);
  row.querySelector('.item-unit').value = item.unit || 'NOS';
  row.querySelector('.item-qty').value = item.qty ?? 1;
  row.querySelector('.item-price').value = item.price ?? '';
  row.querySelectorAll('input').forEach(input => input.addEventListener('input', recalcQuoteTotals));
  document.getElementById('quoteItemsWrap').appendChild(row);
  recalcQuoteTotals();
}

function collectQuoteItems(){
  return [...document.querySelectorAll('#quoteItemsWrap .doc-item-row')].map(row => ({
    name: row.querySelector('.item-name').value.trim(),
    description: row.querySelector('.item-detail').value.trim(),
    hsn: row.querySelector('.item-hsn').value.trim(),
    gstRate: parseFloat(row.querySelector('.item-gst').value) || 0,
    unit: row.querySelector('.item-unit').value.trim() || 'NOS',
    qty: parseFloat(row.querySelector('.item-qty').value) || 0,
    price: parseFloat(row.querySelector('.item-price').value) || 0
  })).filter(it => it.name || it.qty || it.price);
}

function recalcQuoteTotals(){
  const totals = FB.calcItems(collectQuoteItems());
  document.getElementById('quoteSubtotal').textContent = FB.money(totals.subtotal);
  document.getElementById('quoteTax').textContent = FB.money(totals.tax);
  document.getElementById('quoteTotal').textContent = FB.money(totals.total);
  document.getElementById('quoteAmount').value = totals.total.toFixed(2);
}

function populateQuoteCustomers(){
  const sel = document.getElementById('quoteCustomer');
  const customers = FB.get(FB.KEYS.customers, []);
  sel.innerHTML = customers.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
}

function openQuoteModal(){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  document.getElementById('quoteForm').reset();
  document.getElementById('quoteId').value = '';
  populateQuoteCustomers();
  const quotes = FB.get(FB.KEYS.quotations, []);
  document.getElementById('quoteNumber').value = FB.docNumber('quotation', quotes);
  document.getElementById('quoteDate').value = FB.todayISO();
  const d = new Date(); d.setDate(d.getDate()+14);
  document.getElementById('quoteValid').value = d.toISOString().slice(0,10);
  document.getElementById('quoteItemsWrap').innerHTML = '';
  addQuoteItemRow();
  new bootstrap.Modal(document.getElementById('quoteModal')).show();
}

function editQuote(id){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const data = FB.get(FB.KEYS.quotations, []);
  const q = data.find(x => x.id === id);
  if(!q) return;
  populateQuoteCustomers();
  document.getElementById('quoteId').value = q.id;
  document.getElementById('quoteNumber').value = q.number;
  document.getElementById('quoteCustomer').value = q.customer;
  document.getElementById('quoteDate').value = q.date;
  document.getElementById('quoteValid').value = q.validUntil;
  document.getElementById('quoteAmount').value = q.amount;
  document.getElementById('quoteStatus').value = q.status;
  document.getElementById('quoteNotes').value = q.notes||'';
  document.getElementById('quoteItemsWrap').innerHTML = '';
  (q.items && q.items.length ? q.items : [{name:q.notes || 'Service / Goods', qty:1, price:q.amount || 0, gstRate:0, unit:'NOS'}]).forEach(addQuoteItemRow);
  recalcQuoteTotals();
  new bootstrap.Modal(document.getElementById('quoteModal')).show();
}

function deleteQuote(id){
  if(!confirm('Delete this quotation?')) return;
  let data = FB.get(FB.KEYS.quotations, []);
  data = data.filter(x => x.id !== id);
  FB.set(FB.KEYS.quotations, data);
  loadQuotes();
  FB.toast('Quotation deleted', 'info');
}

function convertQuoteToInvoice(id){
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const quotes = FB.get(FB.KEYS.quotations, []);
  const q = quotes.find(x => x.id === id);
  if(!q) return;
  const invoices = FB.get(FB.KEYS.invoices, []);
  invoices.push({
    id: FB.uid('INV'), number: FB.docNumber('invoice', invoices),
    customer: q.customer, date: FB.todayISO(), dueDate: FB.todayISO(),
    amount: q.amount, subtotal:q.subtotal || q.amount, tax:q.tax || 0, status:'pending', items:q.items || []
  });
  FB.set(FB.KEYS.invoices, invoices);
  FB.toast('Converted to invoice', 'success');
}

document.getElementById('quoteForm').addEventListener('submit', function(e){
  e.preventDefault();
  if(!FB.requireActiveSubscriptionForDocuments()) return;
  const id = document.getElementById('quoteId').value;
  const data = FB.get(FB.KEYS.quotations, []);
  const items = collectQuoteItems();
  const totals = FB.calcItems(items);
  const payload = {
    number: document.getElementById('quoteNumber').value,
    customer: document.getElementById('quoteCustomer').value,
    date: document.getElementById('quoteDate').value,
    validUntil: document.getElementById('quoteValid').value,
    amount: totals.total,
    subtotal: totals.subtotal,
    tax: totals.tax,
    status: document.getElementById('quoteStatus').value,
    notes: document.getElementById('quoteNotes').value.trim(),
    items,
  };
  if(id){
    const idx = data.findIndex(x => x.id === id);
    data[idx] = {...data[idx], ...payload};
    FB.toast('Quotation updated', 'success');
  } else {
    data.push({id: FB.uid('QUO'), ...payload});
    FB.toast('Quotation created', 'success');
  }
  FB.set(FB.KEYS.quotations, data);
  bootstrap.Modal.getInstance(document.getElementById('quoteModal')).hide();
  loadQuotes();
});

document.addEventListener('DOMContentLoaded', loadQuotes);
