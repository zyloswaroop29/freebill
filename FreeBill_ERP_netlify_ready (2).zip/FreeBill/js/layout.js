/* =========================================================
   FreeBill ERP — layout.js
   Injects sidebar + topnav on every app page.
   Expects globals set BEFORE this script is loaded:
     window.FB_BASE  = ''  (root pages) or '../' (pages/*.html)
     window.FB_PAGE  = 'dashboard' | 'customers' | ... (active key)
     window.FB_TITLE = 'Dashboard' (topnav title)
   ========================================================= */

(function(){
  const BASE = window.FB_BASE ?? '';
  const ACTIVE = window.FB_PAGE ?? '';
  const TITLE = window.FB_TITLE ?? '';

  const NAV = [
    {key:'dashboard', label:'Dashboard', icon:'fa-chart-pie', href: BASE + 'dashboard.html'},
    {key:'customers', label:'Customers', icon:'fa-users', href: BASE + 'pages/customers.html'},
    {key:'suppliers', label:'Suppliers', icon:'fa-industry', href: BASE + 'pages/suppliers.html'},
    {key:'products', label:'Products', icon:'fa-boxes-stacked', href: BASE + 'pages/products.html'},
    {key:'quotation', label:'Quotation', icon:'fa-file-lines', href: BASE + 'pages/quotation.html'},
    {key:'invoice', label:'Sales Invoice', icon:'fa-file-invoice-dollar', href: BASE + 'pages/invoice.html'},
    {key:'purchase', label:'Purchase Order', icon:'fa-cart-shopping', href: BASE + 'pages/purchase.html'},
    {key:'delivery', label:'Delivery Order', icon:'fa-truck', href: BASE + 'pages/delivery.html'},
    {key:'documents', label:'All Documents', icon:'fa-folder-open', href: BASE + 'pages/documents.html'},
    {key:'inventory', label:'Inventory', icon:'fa-warehouse', href: BASE + 'pages/inventory.html'},
    {key:'reports', label:'Reports', icon:'fa-chart-line', href: BASE + 'pages/reports.html'},
    {key:'notifications', label:'Notifications', icon:'fa-bell', href: BASE + 'pages/notifications.html'},
    {key:'subscription', label:'Subscription', icon:'fa-credit-card', href: BASE + 'pages/subscription.html'},
    {key:'admin', label:'User Management', icon:'fa-user-gear', href: BASE + 'pages/admin.html', adminOnly:true},
    {key:'settings', label:'Settings', icon:'fa-gear', href: BASE + 'pages/settings.html'},
    {key:'profile', label:'Profile', icon:'fa-user', href: BASE + 'pages/profile.html'},
  ];

  function navHtml(){
    // The admin account only needs User Management + Settings; regular users get the full business menu.
    const items = FB.isAdmin()
      ? NAV.filter(item => item.key === 'admin' || item.key === 'settings')
      : NAV.filter(item => !item.adminOnly);
    return items.map(item => `
      <a class="nav-link ${item.key===ACTIVE?'active':''}" href="${item.href}">
        <i class="fa-solid ${item.icon}"></i><span>${item.label}</span>
      </a>`).join('');
  }

  // ---------- Global document search (by number, customer/supplier name, or product name) ----------
  function collectSearchableDocs(){
    const invoices = FB.get(FB.KEYS.invoices, []).map(d => ({
      type:'Sales Invoice', number:d.number, party:d.customer, date:d.date,
      href: BASE + 'pages/invoice.html', items:(d.items||[]).map(i=>i.name)
    }));
    const quotations = FB.get(FB.KEYS.quotations, []).map(d => ({
      type:'Quotation', number:d.number, party:d.customer, date:d.date,
      href: BASE + 'pages/quotation.html', items:(d.items||[]).map(i=>i.name)
    }));
    const purchases = FB.get(FB.KEYS.purchases, []).map(d => ({
      type:'Purchase Order', number:d.number, party:d.supplier, date:d.date,
      href: BASE + 'pages/purchase.html', items:(d.items||[]).map(i=>i.name)
    }));
    const deliveries = FB.get(FB.KEYS.deliveries, []).map(d => ({
      type:'Delivery Order', number:d.number, party:d.customer, date:d.date,
      href: BASE + 'pages/delivery.html', items:(d.items||[]).map(i=>i.name)
    }));
    return [...invoices, ...quotations, ...purchases, ...deliveries];
  }

  function runGlobalSearch(term){
    const box = document.getElementById('globalSearchResults');
    if(!box) return;
    const q = (term || '').trim().toLowerCase();
    if(!q){ box.innerHTML = ''; box.classList.remove('show'); return; }
    const docs = collectSearchableDocs();
    const matches = docs.filter(d =>
      (d.number || '').toLowerCase().includes(q) ||
      (d.party || '').toLowerCase().includes(q) ||
      (d.items || []).some(n => (n || '').toLowerCase().includes(q))
    ).slice(0, 8);

    if(!matches.length){
      box.innerHTML = `<div class="global-search-empty">No documents found for "${FB.escapeHtml(term)}"</div>`;
    } else {
      box.innerHTML = matches.map(m => `
        <a class="global-search-item" href="${m.href}">
          <div>
            <div class="fw-semibold">${FB.escapeHtml(m.number)} <span class="text-muted-c">· ${FB.escapeHtml(m.type)}</span></div>
            <div class="small text-muted-c">${FB.escapeHtml(m.party || '-')} ${m.date ? '· ' + FB.escapeHtml(m.date) : ''}</div>
          </div>
        </a>`).join('');
    }
    box.classList.add('show');
  }

  function sidebarHtml(){
    return `
    <aside class="sidebar" id="fbSidebar">
      <div class="brand">
        <img src="${BASE}assets/logo/logo.svg" alt="logo" id="fbSidebarLogo" class="brand-logo-clickable" title="Click to view logo" onerror="this.style.display='none'">
        <div class="brand-name">FREE<span>BILL</span> ERP</div>
      </div>
      <nav class="sidebar-nav">${navHtml()}</nav>
      <div class="sidebar-foot">
        <a class="nav-link" href="#" id="logoutBtn"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a>
      </div>
    </aside>
    <div class="sidebar-backdrop" id="fbBackdrop"></div>`;
  }

  function topnavHtml(){
    const session = FB.get(FB.KEYS.session) || {name:'Guest', company:'FreeBill'};
    return `
    <header class="topnav">
      <div class="d-flex align-items-center gap-3">
        <button class="icon-btn" id="sidebarToggleBtn"><i class="fa-solid fa-bars"></i></button>
        <div class="page-title">${TITLE}</div>
      </div>
      <div class="d-flex align-items-center gap-3">
        <div class="search-box d-none d-md-flex position-relative">
          <i class="fa-solid fa-magnifying-glass text-muted-c"></i>
          <input type="text" id="globalSearchInput" placeholder="Find document by number, customer or product..." autocomplete="off">
          <div class="global-search-results" id="globalSearchResults"></div>
        </div>
        <button class="icon-btn" id="darkModeToggle" title="Toggle dark mode"><i class="fa-solid fa-moon"></i></button>
        <a class="icon-btn" href="${BASE}pages/notifications.html" title="Notifications"><i class="fa-solid fa-bell"></i><span class="dot" id="notifDot"></span></a>
        <div class="dropdown">
          <button class="avatar-btn btn p-0 border-0 bg-transparent" data-bs-toggle="dropdown">
            <img src="https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(session.name||'U')}" alt="avatar">
          </button>
          <ul class="dropdown-menu dropdown-menu-end glass-card border-0 p-2">
            <li class="px-2 py-1"><strong>${session.name||'Guest'}</strong><br><small class="text-muted-c">${session.company||''}</small></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item rounded" href="${BASE}pages/profile.html">Profile</a></li>
            <li><a class="dropdown-item rounded" href="${BASE}pages/subscription.html">Subscription</a></li>
            <li><a class="dropdown-item rounded" href="${BASE}pages/settings.html">Settings</a></li>
            <li><a class="dropdown-item rounded text-danger" href="#" id="logoutBtn2">Logout</a></li>
          </ul>
        </div>
      </div>
    </header>`;
  }

  function inject(){
    document.body.insertAdjacentHTML('afterbegin', sidebarHtml());
    const main = document.getElementById('mainContent');
    if(main) main.insertAdjacentHTML('afterbegin', topnavHtml());

    // dark mode
    const dm = localStorage.getItem(FB.KEYS.theme);
    if(dm === 'dark'){ document.body.classList.add('dark-mode'); setMoonIcon(true); }
    document.getElementById('darkModeToggle')?.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      const isDark = document.body.classList.contains('dark-mode');
      localStorage.setItem(FB.KEYS.theme, isDark?'dark':'light');
      setMoonIcon(isDark);
    });
    function setMoonIcon(isDark){
      const btn = document.getElementById('darkModeToggle');
      if(btn) btn.innerHTML = isDark ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
    }

    // mobile sidebar
    const sidebar = document.getElementById('fbSidebar');
    const backdrop = document.getElementById('fbBackdrop');
    document.getElementById('sidebarToggleBtn')?.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      backdrop.classList.toggle('show');
    });
    backdrop?.addEventListener('click', () => {
      sidebar.classList.remove('open');
      backdrop.classList.remove('show');
    });

    // logout
    ['logoutBtn','logoutBtn2'].forEach(id => {
      document.getElementById(id)?.addEventListener('click', (e) => { e.preventDefault(); FB.logout(); });
    });

    // global document search
    const searchInput = document.getElementById('globalSearchInput');
    searchInput?.addEventListener('input', () => runGlobalSearch(searchInput.value));
    document.addEventListener('click', (e) => {
      const box = document.getElementById('globalSearchResults');
      if(box && !e.target.closest('.search-box')) box.classList.remove('show');
    });
    const hasUnread = FB.get(FB.KEYS.notifications, []).some(n => !n.read);
    const dot = document.getElementById('notifDot');
    if(dot) dot.style.display = hasUnread ? 'block' : 'none';

    // click logo to view it big
    document.getElementById('fbSidebarLogo')?.addEventListener('click', () => {
      let modalEl = document.getElementById('fbLogoLightbox');
      if(!modalEl){
        document.body.insertAdjacentHTML('beforeend', `
          <div class="modal fade" id="fbLogoLightbox" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content glass-card border-0 text-center p-4">
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
                <img src="${BASE}assets/logo/logo.svg" alt="FreeBill ERP logo" style="max-width:100%;max-height:60vh;margin:0 auto;">
                <div class="fw-bold fs-4 mt-3">FREE<span style="color:var(--primary)">BILL</span> ERP</div>
              </div>
            </div>
          </div>`);
        modalEl = document.getElementById('fbLogoLightbox');
      }
      new bootstrap.Modal(modalEl).show();
    });
  }

  // Blocks the whole app for held / expired / deleted accounts, no matter which page they're on.
  function enforceAccountLock(){
    const lock = FB.accountLockStatus();
    if(!lock) return false;
    if(lock.reason === 'expired'){
      const subPath = BASE + 'pages/subscription.html';
      if(ACTIVE === 'subscription') return false;
      window.location.href = subPath;
      return true;
    }
    document.body.innerHTML = `
      <div class="lock-overlay">
        <div class="glass-card lock-card">
          <i class="fa-solid fa-lock"></i>
          <h4 class="fw-bold mt-3 mb-2">Account Access Restricted</h4>
          <p class="text-muted-c mb-4">${lock.message}</p>
          <a href="mailto:${FB.contactEmail()}" class="btn btn-primary-grad px-4">Contact Us</a>
          <a href="#" id="lockLogoutBtn" class="d-block mt-3 small text-muted-c">Sign out</a>
        </div>
      </div>`;
    document.getElementById('lockLogoutBtn')?.addEventListener('click', (e) => { e.preventDefault(); FB.logout(); });
    return true;
  }

  document.addEventListener('DOMContentLoaded', () => {
    FB.requireAuth();
    if(enforceAccountLock()) return;
    inject();
  });
})();
